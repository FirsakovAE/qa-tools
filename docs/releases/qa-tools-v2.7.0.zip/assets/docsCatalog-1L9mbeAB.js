const h=`---\r
title: AI assistant\r
---\r
\r
# AI assistant\r
\r
The **AI assistant** tab sits after **Logs**. The header on the tab says **AI**. The assistant answers questions about the captured logs and the page. Attaching a request, a component, a store or a log event is described on those tabs.\r
\r
Connection, what the assistant may read, masking, style and the model list are in [Options → AI](/ai/settings). This page is the chat itself.\r
\r
## Before the first question\r
\r
With no API key the tab says **Connect an AI provider** and offers **Connect in Options → AI**. The text names a free key of Gemini or OpenRouter, and your own provider: OpenAI, DeepSeek, a local model (Ollama, LM Studio) or any OpenAI-compatible agent. See [Your own providers](/ai/settings#your-own-providers).\r
\r
With a key but no confirmation, the tab says **Data sent to OpenRouter** or **Data sent to Gemini**, or **Data sent to {name} ({host})** for your own provider:\r
\r
* questions, a digest of the captured logs, the event data and the page code the assistant asks for;\r
* tokens, passwords, API keys and other values from the AI masking list are replaced with \`[MASKED]\` before sending; what the assistant may read is set in **Options → AI → Agent access**;\r
* OpenRouter and Gemini: free models may store prompts and use them for training. Your own provider: that the server is local, or that the data goes to its host under that service's terms; a remote \`http://\` address adds a warning that the key and the data travel unencrypted.\r
\r
OpenRouter and Gemini share one confirmation. Each of your own providers asks for its own. **I understand** confirms. **Review access** opens **Options → AI → Agent access**. Until then the input stays disabled and reads **Connect a provider to ask questions**.\r
\r
After confirmation, an empty chat offers four example questions. Clicking one sends it.\r
\r
## Toolbar\r
\r
| Control | Behavior |\r
| ------- | -------- |\r
| Provider | **OpenRouter**, **Gemini**, then your own providers by name |\r
| Model | Shown when a key is set and the model list has loaded. **Auto** is first: *free models, switches on limits* (your own providers: *listed models, switches on errors*). Then **Recommended** and **Added**. A model note can say **paid**, a status, **unstable**, and how many requests it had today |\r
| **Checking models...** | Shown while the list loads |\r
| **Models failed to load, retry** | Shown when the list fails. The title is the error text |\r
| Refresh | Tooltip **Check which models are available** |\r
| Settings | Tooltip **AI settings: connection, access, masking, style, models**. Opens **Options → AI** |\r
| **New chat** | Tooltip **New chat**. Disabled when the chat is empty and the assistant is idle. Clears the conversation. The conversation stays while the inspector is open, including after switching tabs. Reloading the page starts an empty chat |\r
\r
The model list is hidden until a key exists and models have loaded.\r
\r
## Questions\r
\r
The placeholder is **Ask AI**. With chips attached it is **Ask about the attached data**.\r
\r
**Enter** sends. **Shift+Enter** inserts a line. The send button tooltip is **Send (Enter; Shift+Enter for a new line)**. Send needs text or at least one chip. Sending only chips asks the assistant to explain the attached data and point out anything wrong in it. The chip stays on the question; **×** removes it before sending.\r
\r
While an answer is running the button is **Stop**.\r
\r
## Attaching files\r
\r
**+** next to the field opens two items:\r
\r
* **Text file** (TXT · LOG · JSON · HAR · MD · CSV · PDF): attaches one or more files to the next question, like the chips from the other tabs. The file is not pinned to the chat: it goes with the question it was attached to, and the assistant can read it again in the later questions of the same chat. **New chat** drops it. Files can also be dropped on the field or pasted into it. Up to 64 MB per file. PDF: only the text layer is read; scanned pages and password-protected files are refused.\r
* **Vue inspector Log**: an exported Vue Inspector log. It is pinned to the chat: the logs digest and the logs tools read it instead of the live capture until **New chat**.\r
\r
A long pasted text (over 4000 characters or 60 lines) becomes a chip **Pasted text N** and is handled like a file. A shorter paste goes into the field as usual.\r
\r
A small file (up to about 2000 tokens) goes to the assistant whole. A bigger file is not sent: the assistant gets its overview (size, structure of JSON, requests and failed requests of a HAR, headings of Markdown, columns of CSV, pages of PDF, first lines and error lines of a log) and tools to search the file, read parts of it and query JSON / HAR by path. This keeps the cost of a big file to the parts the question needs. The first step of the answer says **(overview; content read with file tools)** for such a file. The chip tooltip shows the format, size, lines and the estimated tokens.\r
\r
Under the field, when the chat is ready:\r
\r
* OpenRouter: **Today: N of M free OpenRouter requests (counted in this browser). Each assistant step is one request.** **M** is the limit the provider reported, or **50** when it has not. In **Auto**, a second sentence says how many models are skipped because they are out of quota or unavailable.\r
* Gemini: **Today: N Gemini requests. Daily limits depend on the model and your Google AI Studio project.** The same **Auto** sentence can follow.\r
* Your own provider: **Today: N requests to {name} (runs on your server).** for a local one, or **(limits and billing are set by your account there)**, then **Each assistant step is one request.** The same **Auto** sentence can follow.\r
\r
The first step of an answer names where the data went: **Sent to {name} ({host})** for your own provider. With **Tools: No tools** it says **no tools with this connection** instead of the tool access.\r
\r
**Auto** can be selected only when the list has a model that is not marked paid. A hand-picked model must be selected for the field to accept a question.\r
\r
## Answers\r
\r
The question is on the right. The answer is on the left, with the model name and the request count for that answer.\r
\r
**Copy** on a message copies its text. The tooltip becomes **Copied**, or a toast says **Could not copy to the clipboard**. A code block in the answer has its own copy control.\r
\r
A \`#N\` link in the answer opens that event on **Logs**. If it is gone, a toast says **The event is no longer in the logs**.\r
\r
**Try again** on the last answer sends the same question once more. It is disabled while an answer is running or the chat is not ready.\r
\r
If the chosen model fails in a way that is specific to that model, the answer offers **Switch to Auto and try again**. That selects **Auto** and sends the question again.\r
\r
While a run waits for permission, the chat asks **Allow the assistant to read logs?**, **… page code?** or **… the live page?**. The choices are **Allow**, **Allow in this chat** and **Deny**. **Allow in this chat** lasts until **New chat**.\r
\r
A failed answer shows the error in the card. **Provider message** expands the text returned by the provider.\r
\r
## See also\r
\r
* [Options → AI](/ai/settings)\r
* [Working with logs](/logs/general)\r
* [Working with requests](/network/general)\r
* [Components and props](/props/general)\r
* [Pinia stores](/store/general)\r
`,c=`---\r
title: Options → AI\r
---\r
\r
# Options → AI\r
\r
**Options → AI** is the section labeled **AI**. The gear on the [AI assistant](/ai/general) tab opens **Connection**. **Review access** on that tab opens **Agent access**.\r
\r
The blocks follow this order: **Connection**, **Models**, **Personalization**, **Agent access**, **Data masking for AI**.\r
\r
These choices are stored in this browser, apart from the inspector profile. **Export** and **Import** in [Settings management](/options/settings_management) include them, under \`ai\` in the JSON file. API keys and the **Extra headers** of your own providers are not written to the file and are not applied on import. Your own providers are written without them; on import a provider with the same id keeps the key, headers and confirmation stored in this browser, a new one comes without a key and asks for confirmation again, and providers that exist only in this browser stay. **Reset** does not clear **Options → AI**, including the keys and today's request counts. The screen says: *Keys stay in this browser and are not included in settings export.*\r
\r
## Connection\r
\r
**OpenRouter** is listed first, then **Gemini**. Each line says **your own API key**.\r
\r
A saved key is shown as eight dots and its last four characters, with **Remove**. **Remove** clears that key and leaves the provider selected on the AI tab as it is.\r
\r
An empty key shows a password field, **OpenRouter API key** or **Gemini API key**, and **Save**. **Save** is disabled while the field is empty or only spaces. The saved value is trimmed. Saving also selects that provider on the AI tab.\r
\r
Under OpenRouter: **Get a free key in** [OpenRouter](https://openrouter.ai/settings/keys). Under Gemini: **Get a free key in** [Google AI Studio](https://aistudio.google.com/apikey).\r
\r
Until a key is saved, the AI tab uses **Gemini**.\r
\r
### Your own providers {#your-own-providers}\r
\r
Under the built-in providers: **Your own providers** — *OpenAI, DeepSeek, local models, OpenAI-compatible agents*. Any server that answers \`POST {Base URL}/chat/completions\` in the OpenAI format works: a cloud API key, a model on your machine or your own agent. Each provider is a row with its name, then the host, **local** for an address on this machine or the local network, the key as eight dots and its last four characters (or **no key**), and the tool mode. **Edit the connection** opens the same dialog as **Add provider**. **Remove the connection** asks once more in the row (**Remove** / **Keep**); removing drops the key, the model choices and the model marks of that provider, and the AI tab falls back to a built-in provider.\r
\r
**Add provider** opens **Add your own provider**:\r
\r
| Field | Meaning |\r
| ----- | ------- |\r
| **Type** | A preset that fills the fields below; see the table after this one. Changing it replaces only the fields still at the previous preset's values |\r
| **Name** | Up to 40 characters, shown in the provider menus |\r
| **Base URL** | Up to and including the API version, such as \`https://api.openai.com/v1\`. A trailing \`/\` or \`/chat/completions\` is removed. Under the field: where requests go, or a warning for a remote \`http://\` address (the key and the data travel unencrypted) |\r
| **API key** | Required for OpenAI and DeepSeek, optional for the other types. Sent as \`Authorization: Bearer …\` |\r
| **Tools** (Advanced) | **Native tool calls** — the \`tools\` field of the API. **Tools as text** — for servers that reject \`tools\`: the tools are described in the system prompt and the model writes \`<tool_call>{…}</tool_call>\`; tool results go back as user messages. **No tools** — the model answers from the question, attachments and the logs digest only |\r
| **Context size** (Advanced) | **Small (8K tokens)**, **Medium (32K)** or **Large (128K+)**. Smaller sizes send a shorter logs digest, cut tool results, drop earlier questions sooner and allow fewer tool rounds (6, 8 and 10) |\r
| **Stream answers** (Advanced) | On by default. Turn it off when the server breaks streamed responses |\r
| **Extra headers** (Advanced) | One per line, \`Name: value\`, for gateways and proxies (for example \`api-key: …\`). They override the \`Authorization\` header when they name it |\r
\r
| Type | Base URL | Key | Context | Notes |\r
| ---- | -------- | --- | ------- | ----- |\r
| **OpenAI** | \`https://api.openai.com/v1\` | required | Large | Billed to your OpenAI account. Reasoning models (\`o…\`, \`gpt-5…\`) are sent without \`temperature\` |\r
| **DeepSeek** | \`https://api.deepseek.com/v1\` | required | Large | Billed to your DeepSeek balance. The reasoning of \`deepseek-reasoner\` is shown as thinking |\r
| **Ollama** | \`http://localhost:11434/v1\` | — | Small | Start Ollama with \`OLLAMA_ORIGINS=chrome-extension://*\` (or \`*\`); otherwise it answers 403 to the extension. Raise \`OLLAMA_CONTEXT_LENGTH\` (for example 16384) for longer chats. Pick a model with tool support |\r
| **LM Studio** | \`http://localhost:1234/v1\` | — | Medium | Start the server in **Developer** and turn on **CORS** |\r
| **OpenAI-compatible** | yours | optional | Medium | vLLM, llama.cpp, LiteLLM, Groq, Mistral, xAI, Together, your own agent |\r
\r
**Test connection** lists the models (\`GET {Base URL}/models\`) and sends one short request with a test tool. It picks **Tools**: **Native tool calls** when the model called the tool, **Tools as text** when it ignored the tool or the server rejected the \`tools\` field. **Model id for the test** is optional; without it the first offered model is used. A server without a model list needs this id; it is added to the provider's models on **Add**/**Save**. A failure shows the message and **Server response**.\r
\r
The first question to a new provider asks for confirmation again: **Data sent to {name} ({host})**. The text says whether the server is local, or that the data goes to that host under its terms.\r
\r
Common errors of your own providers:\r
\r
* **Could not reach {name} ({host})** — the server is not running, the address is wrong, or (in the [standalone](/standalone) page) the server does not allow cross-origin requests.\r
* **{name} refused the request from the extension** — a local server rejected the extension origin (Ollama: \`OLLAMA_ORIGINS\`).\r
* **{name}: {host} has no such endpoint** — check **Base URL**; it usually ends with \`/v1\`.\r
* **{name} rejected tool calls** — set **Tools** to **Tools as text** or **No tools**.\r
* **{name}: the account has no credits or quota left.**\r
\r
When a server rejects \`temperature\`, \`stream_options\` or \`tool_choice\` with HTTP 400, the request is repeated once without that parameter, and the parameter is left out for that server until the extension page reloads.\r
\r
## Models\r
\r
The provider menu here only chooses whose list to edit. It starts as the provider selected on the AI tab. Changing it does not change that selection.\r
\r
**Reload the model list** is disabled while the list is loading. When the list is loaded, the right side shows **N of M available**: **M** is the recommended models plus the ones you added, **N** is how many of them are still checked.\r
\r
The provider menu lists OpenRouter, Gemini and your own providers. The field **Add or search model** is disabled until that provider has a key (your own providers count as connected once added). Without a key the line is **Connect OpenRouter above to see its models.** or **Connect Gemini above to see its models.** While the list loads: **Loading models...** A failure shows the error text; for your own providers the models already added stay listed under it.\r
\r
The dropdown opens on focus. **Escape** or a click outside closes it.\r
\r
* An empty field lists free models. The hint is **Free models. Type to search paid ones too.**\r
* Any text matches the model name or id, ignoring case, across free and paid models. The hint is **All models of the provider, free and paid.** Free models come first, then the name.\r
* At most **60** rows are shown. The rest is **N more, refine the search**.\r
* Nothing matched: **No models found**.\r
\r
A row shows the name, the id, and **free** or **paid**. **recommended** models are already in the list; their checkbox is disabled. Checking another model adds it. The AI tab shows added models under **Added**.\r
\r
For your own providers the list comes from \`GET {Base URL}/models\`, without embedding, speech and image models, and has no **free**/**paid** badges; the hint is **Models the server lists**. Local providers and lists of up to 8 models offer every model as recommended; longer lists recommend up to three (OpenAI: \`gpt-5-mini\`, \`gpt-5\`, \`gpt-4.1-mini\`…; DeepSeek: \`deepseek-chat\`, \`deepseek-reasoner\`). The field reads **Add or search model, or type a model id**: a typed id the server does not list shows **Add model id …**, and **Enter** adds it too. This is how models of agents and gateways without a model list are added. **Auto** for your own providers picks among the listed models and switches on errors.\r
\r
The list under the field is those recommended and added models.\r
\r
* A checked row is available. Unchecking hides it from the AI tab and from **Auto**. The name is struck through. The status under the name can be **quota used up, resets in …**, **not available for this key**, or **busy, retry in …**. The title is the provider message. **N today** is how many requests that model had today. Badges: **recommended**, **unstable**, **paid**.\r
* The last checked model cannot be unchecked.\r
* **Remove from the list** is on models that are not recommended. It is disabled for the last checked model. Recommended models stay in the list; unchecking is how they are hidden.\r
\r
## Personalization\r
\r
**Defaults** is disabled while the block is already at the defaults: tone **Default**, detail **Normal**, routing **Lite**, and an empty style field.\r
\r
**Base style and tone**\r
\r
| Value | Hint |\r
| ----- | ---- |\r
| **Default** | Balanced answers |\r
| **Professional** | Precise, neutral wording |\r
| **Friendly** | Supportive, plain words |\r
| **Direct** | Conclusion first, no filler |\r
| **Mentor** | Explains the concepts behind the cause |\r
\r
**Answer detail**\r
\r
| Value | Hint |\r
| ----- | ---- |\r
| **Brief** | Cause, key evidence and the fix in a few lines |\r
| **Normal** | What went wrong, the cause, the evidence and the fix |\r
| **Detailed** | The whole chain of events, ruled-out causes, steps to reproduce |\r
\r
**Instruction routing**\r
\r
| Value | Hint |\r
| ----- | ---- |\r
| **Full** | All task instructions in every request. For strong models |\r
| **Lite** | Core rules only; the model loads the instructions of the task when needed |\r
\r
**Your style instructions** holds up to **2000** characters. The placeholder is **For example: answer in Russian, end with a short checklist for the bug report**. The counter is **N / 2000**. The text is saved about **400 ms** after the last change. **Defaults** during that wait can be overwritten by the pending save, so the cleared text comes back.\r
\r
## Agent access\r
\r
The description is **What the assistant may read and send to the provider.** **Defaults** restores the values below and is disabled while they are already set.\r
\r
**Attach the logs digest to questions** — hint **A short summary of errors and the timeline.** **Allowed** by default. **Off** sends the question without that summary. The first step of the answer then says **no logs digest (turned off)**.\r
\r
**Tools.** Each group is **Allowed**, **Ask each time**, or **Off**. The default is **Ask each time**. **Ask each time** uses the confirmation on the [AI assistant](/ai/general) tab. **Allowed** runs the tool without asking. **Off** does not give that group to the assistant. Reading this documentation stays available.\r
\r
| Group | Hint |\r
| ----- | ---- |\r
| **Logs** | Event details and search over the captured logs |\r
| **Page code** | List, read and search the scripts of the page and their source maps |\r
| **Live page** | Find elements on the page, why they are disabled or hidden, their components, handler code and the current store state |\r
\r
**Data in the logs.** Each line is **Allowed** or **Off**. All three are **Allowed** by default. **Off** replaces the hidden part with \`[hidden by AI access settings]\`. Store, props, emit and action values that are off become a type in brackets, such as \`[string]\`, while names and paths stay.\r
\r
| Line | Hint |\r
| ---- | ---- |\r
| **Request and response headers** | Sensitive headers stay masked |\r
| **Request / response bodies and WebSocket messages** | |\r
| **Values of store state, props, emits and actions** | Off: only names, paths and types |\r
\r
## Data masking for AI\r
\r
This list is applied when data is sent to the provider. It does not change the **Logs** tab or an HTML report. The Logs mask still runs first. See [Data masking](/logs/settings#data-masking) for how a fragment matches a key and for \`[MASKED]\`, \`[MASKED JWT]\`, \`Bearer [MASKED]\` and \`[MASKED CARD]\`.\r
\r
The text under the title: **Values with matching names in objects, headers, URLs, and code are sent as [MASKED].**\r
\r
**Mask sensitive data** is the value-pattern checkbox. It is on by default. While it is off, only the key list is applied.\r
\r
The column is **Key contains**. The empty table says **No keys — only value patterns are masked**. The placeholder is **Key fragment, e.g. x-client-secret**. **Add** or **Enter** trims the fragment. An empty value shows **Key cannot be empty**. The same fragment, ignoring case, shows **This key is already in the list**. The row menu is **Delete**. Clicking a row does nothing.\r
\r
The default fragments are the [Logs list](/logs/settings#data-masking) plus \`passcode\`, \`auth\`, \`bearer\`, \`jwt\`, \`credential\`, \`session\`, \`csrf\`, \`xsrf\`, \`signature\`, \`accesskey\`, \`passphrase\`.\r
\r
\`passcode\` is put back if the saved list does not already contain it. **Delete** on that row does not keep it removed.\r
\r
**Defaults** restores the key list and turns **Mask sensitive data** on. The button stays enabled when the list is already the default.\r
`,p=`---\r
title: Browser extension\r
---\r
\r
### Chrome / Edge extension\r
\r
> Primary launch mode for Vue Inspector with automatic launch, separate window mode, popup menu access, and browser integration.\r
\r
## Data storage\r
\r
Settings and saved media are stored in **browser profile storage** (separate from the sites being inspected): once saved in Options, the same data becomes available across all tabs. Comparison with standalone mode and storage details by data type are described in [Installation → Where settings are stored](./install#storage).\r
\r
---\r
\r
## Installation\r
\r
1. Open the <a href="../../index.html#installation" target="_self" rel="noopener">installation section</a> on the main project page.\r
2. Download the latest extension archive;\r
3. Extract it to a convenient folder;\r
4. Open \`chrome://extensions/\`;\r
5. Enable **Developer mode** in the upper-right corner;\r
6. Click **Load unpacked**;\r
7. Select the extension folder.\r
\r
---\r
\r
## Usage\r
\r
After installation, the extension becomes available in the browser and can launch according to your current settings.\r
\r
It can also be launched manually from the extension popup when needed.\r
\r
---\r
\r
## Incognito mode\r
\r
To use the extension in incognito mode:\r
\r
1. Open \`chrome://extensions/\`;\r
2. Find **Vue Inspector** in the installed extensions list;\r
3. Open **Details**;\r
4. Enable **Allow in incognito**.\r
\r
The extension will then also be available in private browser windows.\r
`,u=`---\r
title: General UI principles\r
---\r
\r
# General UI principles\r
\r
High-level patterns shared across Vue Inspector panels. For **where** the UI runs (overlay, DevTools tab, standalone window), see [Display modes](/options/display_mode) and [Installation](/install).\r
\r
![Props, полноэкранный режим](/screenshots/Props_full_screen.jpg)\r
\r
## Navigation\r
\r
The UI is built around two main tabs: the primary data area and a secondary detail area. In narrow layouts the two can merge into a single working surface.\r
\r
## Working with rows\r
\r
In all tables you can act on a row in two ways:\r
\r
* the **⋯** menu on the row;\r
* the **right-click** context menu.\r
\r
Both are equivalent and appear across the main areas of the app.\r
\r
## Top toolbar\r
\r
Most panels share a common top toolbar with search and extra actions. What appears there depends on the current mode and the kind of data shown.\r
\r
![Props, область заголовка](/screenshots/Props_header.jpg)\r
\r
## Search\r
\r
Search is a cross-cutting feature in the main panels.\r
\r
The runtime provides a built-in search affordance:\r
\r
* **Ctrl+F** — uses the browser’s or DevTools find‑in‑page behavior (and how it interacts with the panel depends on [display mode](/options/display_mode) and the structure of the current view).\r
\r
For section-specific filters (requests, props, store), see the relevant docs — for example [Network — working with requests](/network/general).\r
\r
## Keyboard shortcuts\r
\r
Common shortcuts:\r
\r
* **Ctrl+F** — search in the current panel (see above);\r
* **Esc** — cancel the current action, e.g. close a detail view or exit [Inspect](/props/inspect) mode.\r
\r
## Detail views\r
\r
Many entities open a **detail** view when selected. **Esc** or navigating back returns to the previous UI state.\r
\r
![Детализация props](/screenshots/Props_details.jpg)\r
\r
## Display modes\r
\r
Depending on launch context — **Overlay**, **DevTools**, or **Standalone** — layout and chrome can differ slightly while keeping the same overall behavior. See [Display modes](/options/display_mode), [Browser extension](/extension), and [Standalone app](/standalone).\r
`,m=`---\r
title: Introduction\r
layout: doc\r
---\r
\r
# Introduction\r
\r
## What is Vue Inspector?\r
\r
**Vue Inspector** is a tool for analyzing Vue applications at runtime without requiring access to source code, a local build, or a dedicated development environment.\r
\r
The extension allows you to explore the application structure directly on the loaded page: inspect props, store data, network requests, and internal component state exactly as they exist while the application is running.\r
\r
It is designed for scenarios where you need to quickly understand the current frontend state without relying on additional development tools.\r
\r
---\r
\r
## Why use Vue Inspector?\r
\r
Vue Inspector helps simplify application analysis when standard browser tools are not sufficient or when faster access to runtime data is required.\r
\r
Main capabilities:\r
\r
* View component props in real time;\r
* Inspect received and declared props;\r
* Access store data without manually searching runtime structures;\r
* Browse network requests in a structured format;\r
* Keep a single journal of requests, props, emits, store changes, navigation and errors, and export it as an HTML report;\r
* Jump quickly to related data inside the application;\r
* Select components directly on the page using Inspect mode;\r
* Filter and locate required data without manually traversing the DOM structure;\r
\r
---\r
\r
## How is Vue Inspector different from standard DevTools?\r
\r
Unlike Vue Devtools, Vue Inspector is designed not only for local development but also for working with already running applications where:\r
\r
* source code is unavailable;\r
* no local project build is accessible;\r
* production or test environments need to be explored quickly;\r
* runtime data must be inspected without preparing a development environment;\r
\r
---\r
\r
## When is it especially useful?\r
\r
Vue Inspector is particularly useful for:\r
\r
* frontend application testing;\r
* analyzing complex integrations;\r
* investigating component behavior;\r
* locating data transfer issues;\r
* verifying reactive application state;\r
\r
---\r
\r
## Additional Notes\r
\r
The project continues to evolve and gradually expands runtime analysis support for various frontend scenarios.\r
`,g=`---\r
title: Installation\r
---\r
\r
# Installation\r
\r
Vue Inspector is available in more than one launch mode so you can use it across environments and browsers.\r
\r
The right mode depends on environment constraints, security policy, and how you prefer to work.\r
\r
<div class="install-options">\r
  <a class="install-option-card" href="./extension">\r
    <span class="install-option-icon install-option-icon--brand" aria-hidden="true">\r
      <img src="/install/chrome-logo.svg" alt="" width="32" height="32" loading="lazy" decoding="async" />\r
    </span>\r
    <span class="install-option-body">\r
      <span class="install-option-title">Browser extension</span>\r
      <span class="install-option-desc">Full control inside the browser.</span>\r
    </span>\r
  </a>\r
  <a class="install-option-card" href="./standalone">\r
    <span class="install-option-icon install-option-icon--brand" aria-hidden="true">\r
      <img src="/install/electron-logo.svg" alt="" width="32" height="32" loading="lazy" decoding="async" />\r
    </span>\r
    <span class="install-option-body">\r
      <span class="install-option-title">Standalone app</span>\r
      <span class="install-option-desc">For strict policies and any browser.</span>\r
    </span>\r
  </a>\r
</div>\r
\r
## Which option should I choose?\r
\r
* **Chrome extension** — when you need persistent access and the full feature set: auto-run, DevTools integration, and advanced in-browser workflows.\r
* **Standalone application** — when extensions cannot be installed, enterprise restrictions apply, or independent launch is required.\r
\r
---\r
\r
## Where are settings stored? {#storage}\r
\r
Both the **extension** and **standalone** use **a single shared settings profile** for the browser: once saved in Options, the same values apply on **every site** where you open the inspector. No separate per-domain configuration is required.\r
\r
Only the **storage mechanism** differs: the extension uses Chrome’s built-in storage for installed components, while standalone uses a **dedicated local storage layer** for the application (without installation in \`chrome://extensions\`), created specifically for this mode.\r
\r
|                                                                               | **Extension**                                                                                                                                         | **Standalone (bookmark)**                                                                                                                 |\r
| ----------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------- |\r
| **Settings** (options, favorites, site lists, etc.)                           | The extension’s **internal browser storage** within the browser profile: data is tied to the installed Vue Inspector instance, not to a specific tab. | **Dedicated** standalone local storage — same concept: one shared database for all sites launched through the bookmark.                   |\r
| **Customize assets** (backgrounds, saved media from Customize and related UI) | Stored separately in **browser storage** under the extension context (files remain in the browser profile, not “on the site”).                        | Stored in the **same unified** standalone storage, subject to its limits (see [Customize](/options/customize)).                           |\r
| **Across sites**                                                              | One shared settings profile across all domains in the current browser profile.                                                                        | One shared settings profile across all domains: storage is **not bound** to page origin, so reuse works the same way as in the extension. |\r
\r
For media limits in Customize, see [Customize](/options/customize).\r
\r
**Saving and transfer:** regular changes in Options **autosave** (with a small debounce). The **extension** stores settings in **IndexedDB** and **\`chrome.storage.local\`**; **standalone** keeps a snapshot in its **central KV store** (IndexedDB), while media is stored separately with a size limit. **Export / Import / Reset** in General provide JSON export and full reset; differences between modes during export and import are described in [Settings management](/options/settings_management).\r
`,f=`---\r
title: Export\r
---\r
\r
# Export\r
\r
Events from the **Logs** tab can be saved to an **HTML** report and opened in any browser. This is useful for bug reports, for sharing a scenario with colleagues and for analysis outside the page.\r
\r
General information about the tab: [Working with logs](./general.md).\r
\r
---\r
\r
## Export format\r
\r
Every export is one **HTML** file: a static report that opens in the browser. The report itself downloads the other formats (see [Downloads from the report](#downloads-from-the-report)).\r
\r
The data inside the report is compact, like the live log (see [How events are stored](./general.md#how-events-are-stored)): store changes are diffs, a request and its response share one network entry, equal bodies are stored once, and identical values in any event are stored once as a shared snapshot. Titles, Before / After states, snapshot values and request / response details are restored when the report is opened.\r
\r
The embedded data uses format version 1.\r
\r
---\r
\r
## What is exported\r
\r
### Export Logs\r
\r
* Without a selection — all events visible in the table after **Search** and **Type** filters.\r
* With a selection — only the rows ticked in the checkbox column; the button shows **Export Logs (n)**.\r
* Checking **Send request** or **Receive response** also checks the other event of the same request, and clearing one clears both, so **Export Logs (n)** counts both. If a filter hides one half, that half is still added to the file. A WebSocket frame stays the event that was selected.\r
\r
The button is disabled while the filtered list is empty.\r
\r
### Single event\r
\r
**Export event** in the **⋮** menu of the details header or in the row context menu exports one event.\r
\r
For a network event, **Send request** and **Receive response** of the same request are exported together in one file, so the request and its response are never separated. A WebSocket event is exported on its own.\r
\r
### Pinia changes in a partial export\r
\r
A **Change store** event is a diff against the previous event of the same store. When that previous event is not part of the export (a selection, a filter or a single event), the exported change also carries the full state after it and the old values of the changed fields, so **Before** / **After** stay available in the file.\r
\r
### Files\r
\r
| Export | File name |\r
| ------ | --------- |\r
| **Export Logs** | \`logs_<date>_<time>.html\` |\r
| Network pair | \`log_network_<date>_<time>.html\` |\r
| Other single event | \`log_<type>_<date>_<time>.html\` |\r
\r
Data is masked at capture time, so the files contain the same masked values as the view (see [Logs settings](./settings.md#data-masking)).\r
\r
---\r
\r
## HTML report\r
\r
The **HTML** report is one self-contained file: styles, scripts, the application icon and the event data are embedded. It uses a dark theme and does not load external resources.\r
\r
**Compress report** (**Options → Logs → Export**) is on by default. The file then stores the same JSON as gzip in base64. Opening it needs a browser with \`DecompressionStream\` (Chrome / Edge 80+, Firefox 113+, Safari 16.4+). An older browser shows **This report is compressed and this browser cannot unpack it. Open it in Chrome / Edge 80+, Firefox 113+ or Safari 16.4+.** When the browser that exports the file cannot compress, the checkbox is disabled and the file is plain HTML. See [Logs settings](./settings.md#export).\r
\r
### Sidebar\r
\r
* **Report** — **Overview** and **All events** with the total count;\r
* sections by type with counters: **Network** (**Send request**, **Receive response**), **WebSocket** (**WebSocket open**, **WebSocket sent**, **WebSocket received**, **WebSocket closed**), **Components** (**Change props**, **Emit**), **Pinia** (**Change store**, **Store action**), **Page** (**Navigation**, **Click**, **JS error**);\r
* **Download Vue Inspector** at the bottom — link to the project page.\r
* **Support Vue Inspector** above it: **Monthly support** opens Boosty, **Donate with USDT** shows the Tron (TRC-20) address, a QR code and **Copy address**.\r
\r
### Overview\r
\r
Summary cards: **Events**, **Errors**, **Failed requests / WS**, first and last event time, time span; counters by type; export information. **Generator** is **Vue Inspector Extension** or **Vue Inspector Bookmarklet**, matching the mode that created the file. **Format version** is 1.\r
\r
**Failed requests / WS** counts a **Receive response** with a network error or status **400** or higher, and a **WebSocket closed** event with an error, with **No automatic reconnect**, or with a close code other than empty, **1000**, **1001** or **1005**.\r
\r
The header shows **Vue Inspector** with that mode in a tag, **Logs report** on the next line, and the event count with the export time centered beside those two lines.\r
\r
**Events**, **Errors** and **Failed requests / WS** are clickable: they open **All events** with the matching filter. The active filter is shown as a chip above the list; clicking the chip removes it.\r
\r
### Event list and details\r
\r
* Search in the top bar; with **in data** enabled the search also looks inside event data.\r
* **All events** has a **Type** dropdown with checkboxes. It lists only the types present in the file, all on by default. **Select all** and **Clear** turn that list on or off. With every type off, the list says **No event types selected — enable them in the Type filter**. A search or chip that matches nothing says **No events match the filters**. An empty section says **No events**. The filter stays on this page while you search or use the **Errors** / **Failed requests / WS** chip, and does not change the sidebar sections.\r
* Clicking a row opens details with the same tabs as in the app (**Overview**, **Params**, **Headers**, **Body**, **Changes**, **Before** / **After**, **State**, **Raw**, etc.). Every JSON and text block has the same bar on top: **Find**, the previous / next match arrows, the match count and **Copy**. JSON is indented and colored, including a truncated body. **Find** searches the whole block and highlights the matches; Enter and Shift+Enter move between them, Esc clears the field. **Copy** copies the stored text. While details with such a block are open, Ctrl+F (Cmd+F) moves to its **Find** field in any keyboard layout; a second Ctrl+F opens the browser find. A block larger than **200 KB** fills the details area and keeps only the visible lines in the page, so only **Find** sees all of it. Smaller blocks are on the page in full, so the browser find works on them too.\r
* A binary response shows the same yellow notice as a truncated body, *Binary response received. Body not included in report.*, above the type line (\`image/jpeg (986.2 KB)\` and **Binary**).\r
* **WebSocket open**, **WebSocket sent**, **WebSocket received** and **WebSocket closed** are a separate **WebSocket** section. A message is pretty-printed JSON when the frame is JSON. **Sent** or **Received** and the size sit above that block, in the same type-and-size line as a binary file. **WebSocket closed** lists each frame the same way. When the tab holds several messages, one **Find** bar sits above them and stays visible while scrolling: it searches all messages together, the count and the arrows go through the matches across the messages, and each message keeps its own **Copy**. **Overview** shows the close code, the reason and **No automatic reconnect** when that was determined.\r
* For network events, **Request** or **Response** in the details header jumps between the request and its response. A WebSocket frame or the open event uses **Closed**; the close event uses **Opened**.\r
* **Locate** opens **All events** and scrolls so this event is in view, the same way **Request** / **Response** brings its pair into view. If its type was switched off, that type is switched on so the event stays in the list. When the details panel covers the list, **Locate** also closes the panel so the event stays visible in the list.\r
* The details panel closes with the back arrow on the left (the same control as in the app) or with **Esc**.\r
* **↑ / ↓** move between events.\r
* The selected section and event are kept in the address (\`#…\`), so a link to a specific event can be shared and survives a reload.\r
* On a narrow screen the section list opens from the menu button. Choosing a section closes it, and a tap outside it closes it. Event rows show a colored bar for the event type.\r
\r
### Downloads from the report\r
\r
Two buttons in the top bar download the events of the report:\r
\r
| Button | File | Content |\r
| ------ | ---- | ------- |\r
| **Brief for AI** | \`<report>.ai.md\` | A compact Markdown digest (errors, failed requests, timeline) with a guide for an AI assistant |\r
| **RAW JSON** | \`<report>.raw.json\` | Every event in full, oldest first, indented: the same object the **Raw** tab shows, with restored store states, change values and the request / response details. A WebSocket message keeps only its own frame |\r
\r
On a narrow screen the buttons are shortened to **Brief AI** and **RAW**.\r
\r
---\r
\r
## See also\r
\r
* [Working with logs](./general.md)\r
* [Logs settings](./settings.md)\r
* [Export collections](/network/export)\r
`,w=`---\r
title: Working with logs\r
---\r
\r
# Working with logs\r
\r
The **Logs** tab is a single chronological journal of what happens on the page: network requests, component props and emits, **Pinia** changes and actions, SPA navigation, clicks and JS errors. It helps to reconstruct a scenario step by step and to hand it over as a file.\r
\r
The tab is always visible, comes after **Pinia Stores**, and records events the same way in the extension and in **Bookmark** ([Standalone](/standalone)) mode.\r
\r
## Event types\r
\r
| Type | What is logged |\r
| ---- | -------------- |\r
| **Send request** | Outgoing **fetch** / **XMLHttpRequest** call: URL, method, initiator, **Params**, request **Headers**, **Authorization**, request **Body** |\r
| **Receive response** | Response to that call: status, duration, size, response **Headers**, response **Body**, network error |\r
| **WebSocket open** | The connection opened: URL and handshake **Headers**. Its own type in the **Type** filter |\r
| **WebSocket sent** | One outgoing frame. Each frame is its own event |\r
| **WebSocket received** | One incoming frame. Each frame is its own event |\r
| **WebSocket closed** | Close of that connection: close code, reason, duration, size, and **No automatic reconnect** when the protocol says the client will not open a new socket |\r
| **Change props** | Changed props of a component: list of changes and full **Before** / **After** snapshots |\r
| **Emit** | Component event: component, event name, arguments, listener type (**regular** / **once**), parent chain |\r
| **Change store** | Changed **Pinia** state: list of changes and full **Before** / **After** snapshots. The type also includes the store's base states: **Store initialized**, **Store snapshot** and **Store checkpoint** (see [How events are stored](#how-events-are-stored)) |\r
| **Store action** | **Pinia** action call: arguments, result or error, status, duration |\r
| **Navigation** | SPA navigation: **pushState**, **replaceState**, **popstate**, **hashchange** with **From** / **To**. When logging starts, and after **Clear**, the current page is recorded as **snapshot** |\r
| **Click** | A primary click: **XPath** of the field or button (its **id** when that id is unique and stable, otherwise an absolute path) and **Text** inside that control. A click on an icon inside a button is recorded as the button. Clicks on Vue Inspector itself are skipped. The value of a password or hidden field is not stored |\r
| **JS error** | Uncaught error, unhandled promise rejection or \`console.error\` of the page: message, source, location, compact stack (see [JS errors](#js-errors)) |\r
\r
Each network call produces **two** events that share one network entry. **Send request** shows what was sent, **Receive response** shows what came back. A WebSocket writes a separate event for the open connection (**WebSocket open**), for every sent frame, for every received frame and for the close. Those four types are in the **Type** filter. They share one stored connection, so the handshake and the frame text are kept once. After a request is edited at a [Breakpoint](/network/traffic), both events show the data that was actually sent and received.\r
\r
## Top toolbar\r
\r
### Search\r
\r
The search box placeholder is **Search events...**. The active criteria are set in **Options → Logs → Search Settings** (see [Logs settings](./settings.md)):\r
\r
| Mode | Description |\r
| ---- | ----------- |\r
| **Search by event name** | Title, subtitle, the event key, and the request URL. On by default |\r
| **Search by key** | Keys in the payload and changed paths |\r
| **Search by value** | Values in the payload |\r
\r
**Search by event name** stays on when **Search by key** and **Search by value** are both off, so a query still matches names.\r
\r
For **Change store** and **Change props**, key and value search looks at the changed paths and values; full states are searched in the **Store initialized**, **Store snapshot** and **Store checkpoint** events. The index walks nested data to depth 20 and keeps at most 200 000 characters of keys and 200 000 of values per event.\r
\r
A query **without** quotes matches a substring. A query wrapped in **double quotes** \`"..."\` matches the whole string. Both ignore case. Minimum length and debounce come from **Options → General → Search Parameters** (default **2** characters and **300 ms**, [Update settings](/options/update_settings)). The length is the text inside the quotes. A shorter non-empty query does not start a new search; the previous result stays until the field is cleared or the query reaches the minimum.\r
\r
### Type\r
\r
**Type** limits the table to the selected event types. All types are on by default. The menu footer has **Select all** and **Clear**. With every type off the table says **No event types selected — enable them in the Type filter**. A search or type filter that matches nothing says **No events match the filters**. An empty buffer says **No events logged yet**.\r
\r
### Status indicators\r
\r
| Item | Purpose |\r
| ---- | ------- |\r
| **N** or **N/M** | **N** is visible rows. **/M** appears when a search or a **Type** filter is active and the counts differ. **M** is every event in the buffer |\r
| **ignored** | Shown only when at least one group is ignored. The number is the ignore list. Click opens **Options → Logs**, the **Ignore list** table |\r
| **Paused** | Shown while recording of new events is paused |\r
\r
### Log controls\r
\r
| Control | Purpose |\r
| ------- | ------- |\r
| **Pause** / **Resume** | Icon button. Tooltip **Pause logging** or **Resume logging**. The icon is orange while paused |\r
| **Clear** | Tooltip **Clear all**. Disabled when the buffer is empty. Removes every recorded event and the row selection |\r
| **Export Logs** | Export events to an **HTML** report (see [Export](./export.md)). On a narrow toolbar the button moves to the row under the search field |\r
\r
## Work area\r
\r
### Events table\r
\r
| Column | Content |\r
| ------ | ------- |\r
| Checkbox | Selection for export |\r
| **Time** | Event time with milliseconds |\r
| **Type** | Colored type badge |\r
| **Event** | Title and short description (method and path, component and event, store and changed keys, etc.) |\r
\r
Rows are highlighted by level: **4xx** responses — warning; **5xx**, network errors, failed actions and JS errors — error.\r
\r
### Selection for export\r
\r
The first column contains checkboxes, in the same position as the favorites star in **Props** and **Pinia**.\r
\r
| Action | Result |\r
| ------ | ------ |\r
| Click a checkbox | Select / unselect a row. **Send request** and **Receive response** of the same request are selected and cleared together |\r
| **Shift** + click | Select a range from the last clicked row |\r
| **Ctrl / Cmd** + click on a row | Toggle a row without opening details |\r
| Header checkbox | Select all / clear selection |\r
\r
When rows are selected, the button shows **Export Logs (n)** and exports only them as an **HTML** report. Without a selection, all filtered events are exported.\r
\r
### Event details\r
\r
Clicking a row opens details on the right. The layout follows **Network**: a tab strip, name/value tables and **JSON** blocks in the [JSON editor](/options/json_mode).\r
\r
| Type | Tabs |\r
| ---- | ---- |\r
| **Send request** | **Overview**, **Params (n)**, **Headers**, **Body**, **Raw** |\r
| **Receive response** | **Overview**, **Headers**, **Body**, **Raw** |\r
| **WebSocket open** | **Overview**, **Headers**, **Messages (n)**, **Raw** |\r
| **WebSocket sent**, **WebSocket received** | **Overview**, **Headers**, **Message**, **Raw** |\r
| **WebSocket closed** | **Overview**, **Headers**, **Messages (n)**, **Raw** |\r
| **Change props**, **Change store** | **Changes (n)**, **Before**, **After**, **Raw** |\r
| **Store initialized**, **Store snapshot**, **Store checkpoint** | **Overview**, **State**, **Raw** |\r
| **Store action** | **Overview**, **Arguments**, **Result** / **Error**, **Raw** |\r
| **Emit** | **Arguments (n)**, **Overview**, **Raw** |\r
| **Navigation**, **JS error** | **Overview**, **Stack** (errors), **Raw** |\r
| **Click** | **Overview**, **Raw** |\r
\r
**Changes** shows a diff by path: added, removed and changed values with the old and new value. Very large diffs are truncated; the full state stays available on **Before** / **After**.\r
\r
**Before** / **After** of a store change are restored from the store's base state and the changes after it. When that is impossible (the earlier events of the store are no longer in the log), the tab says so and **Changes** still shows the changed values; a value that cannot be restored is shown as *not available*.\r
\r
**Raw** shows the event with all restored fields.\r
\r
If a network body was larger than the configured event size, **Body** shows a notice with the original size.\r
\r
A binary **Receive response** uses the same bar as **Network**, directly under the section tabs: content type, size and a **Binary** badge, for example \`image/jpeg (986.2 KB)\`. The file itself is not stored. **Duration** on **Store action** and **Receive response** is shown with two digits after the decimal point (\`635.90 ms\`).\r
\r
### Event actions\r
\r
Actions are available in the **⋮** menu of the details header and in the row context menu (right click or **⋮** in the row):\r
\r
| Action | Purpose |\r
| ------ | ------- |\r
| **Ask AI** | Attach the event to a question for the assistant. The **AI** tab opens with a chip above the input that shows the event name: **×** removes it from the question. Type a question, or send the chip without one. The assistant gets the full event with its id \`#N\`, masked and cut by the AI settings |\r
| **Export event** | Export one event. For a network event, **Send request** and **Receive response** of the same request go into one file. A WebSocket event exports that one event |\r
| **Copy cURL** | Copy the request as a cURL command (also available on **Receive response**: both events share the request data). WebSocket events do not have this action |\r
| **Open request event** / **Open response event** | Jump to the paired network event. A WebSocket uses **Open connection event** / **Open close event** |\r
| **Ignore** | Stop logging this group of events |\r
\r
**Ignore** works per group: the same request (method and path), the same component, the same store, and so on. Ignored groups are not recorded at all. The **ignored** indicator in the toolbar opens **Options → Logs**, the **Ignore list**, where **Log again** resumes one group and **Log all again** resumes every group.\r
\r
## How it works\r
\r
### When recording starts\r
\r
Recording starts together with the rest of Vue Inspector in the tab context. Events are kept in the page, so the history is available when **Logs** is opened later, without reloading the page.\r
\r
### How events are stored {#how-events-are-stored}\r
\r
Events keep only primary data; titles, descriptions and full states are derived when an event is shown.\r
\r
* **Pinia.** When a store is created while logging is running, a **Store initialized** event records its full state. When logging starts on a store that already exists, a **Store snapshot** event records its current state. After that, every **Change store** event stores only the changes. **Before** / **After** are rebuilt from the base state and the changes up to the event. Switching Inspector tabs does not create new snapshots. A new snapshot is recorded after **Clear** and after masking settings change. A recorded state is split like on the **Pinia Store** tab: \`state\` holds the declared state, \`getters\` holds getters and data the store keeps outside its declared state (for example, fields assigned in actions of an options store with an empty \`state()\`). Changes of both are tracked, so change paths start with \`state.\` or \`getters.\`.\r
* **Network.** **Send request** and **Receive response** reference one shared network entry. WebSocket events reference one shared connection: the open event, each frame and the close. Equal response or request bodies (for example, a polled endpoint) are stored once. A duration tick while the socket stays quiet does not add a new event.\r
* **Shared snapshots.** Identical values inside any event — props, store state, action arguments and results, emit arguments, errors, navigation — are stored once. Each later copy is a reference to that snapshot. The Logs tab and the HTML report restore the full value, so the data you see is the data that was captured.\r
\r
### Limits\r
\r
A shared memory budget keeps long sessions stable. When it is reached, the log is cut at a **Navigation**: every event recorded before that navigation is removed, whatever its type — network requests and responses, WebSocket, props, Pinia, emits, store actions and errors. Events from the navigation onward stay. Each earlier navigation is a cut in turn, so the oldest period goes first. The last navigation is rewritten as a snapshot of the page at that moment (\`from\` is cleared), and events before it are removed the same way. If the log is still over the budget, the oldest remaining events are removed by age. The newest event is always kept, even if it alone exceeds the budget. **Limit event size** is on by default at **512 KB**, so larger parts of an event are cut. Groups of events can be switched off completely. Defaults and settings are described in [Logs settings](./settings.md).\r
\r
**Send request** and **Receive response** follow **Maximum HTTP requests** (**Options → Network**, default **500**): an older request leaves the log together with its response. **WebSocket open**, **WebSocket sent**, **WebSocket received** and **WebSocket closed** follow **Maximum WebSocket events** (the same screen, default **500**): each of those records counts as one, and the oldest are dropped. Both rings are separate from the memory budget.\r
\r
A **Pinia** chain is not broken by a cut. Changes up to the cut are rebuilt into one **Store checkpoint** with the store state at that point, placed before the events that remain. The previous base and the diffs that produced it are deleted. Later **Change store** events still restore **Before** / **After** from that checkpoint. A store whose next remaining event is already a full state does not get a checkpoint; its older events are removed.\r
\r
### JS errors {#js-errors}\r
\r
**JS error** events come from three sources, shown in **Overview** as **Source**: **Uncaught error**, **Unhandled rejection** and **console.error**.\r
\r
* **Only the inspected page.** Whether an error is the page's is decided by where it comes from (the caller in the stack), not by its text. Messages and errors of Vue Inspector itself and of other browser extensions are not logged. This includes Vue Inspector's internal reports about failed **fetch** / **XHR** requests: such a request is already a **Network** event. The app's own \`console.error\` about a failed request is kept.\r
* **console.error.** The message is built like in the browser console (\`%s\`, \`%d\`, \`%o\` and similar are applied, objects are shown as a short preview); object arguments are kept in **Raw**. **Location** points to the line of the app that called \`console.error\`, or to the top frame of an error passed to it. More than 50 messages per second are not logged; the next event shows how many were skipped (**Suppressed**).\r
* **Compact stack.** The message is kept. A stack longer than 10 frames keeps the first 5 and the last 5; the middle is replaced by *… N more frames (stack truncated)*. **Overview** shows **Stack: Truncated** with how many frames were kept from each end.\r
\r
Errors of the inspected page stay in the page console and in **Logs**. They are not added to the extension error list (\`chrome://extensions\`); that list shows only failures of Vue Inspector itself. A page exception from **WebSocket** \`send\` or \`close\`, such as **WebSocket is already in CLOSING or CLOSED state**, is included: the wrapper that records the frame runs in the page. A failed **fetch**, an aborted or timed-out request, and a response body that could not be read because the connection dropped (**Failed to fetch**, **network error**) are recorded only as a Network row. While logging runs, a page \`console.error\` passes through a small page-side bridge, so the browser console may attribute that line to the bridge. The message and the stack are unchanged.\r
\r
### Data masking\r
\r
Sensitive data is masked **when an event is captured**, so it never reaches the view or exports: passwords, tokens, cookies, authorization headers, card numbers and similar keys, as well as **JWT**, **Bearer** / **Basic** credentials and card numbers inside any text.\r
\r
## See also\r
\r
* [Export](./export.md)\r
* [Logs settings](./settings.md)\r
* [Working with requests](/network/general)\r
`,v=`---\r
title: Logs settings\r
---\r
\r
# Logs settings\r
\r
**Options → Logs** collects the settings of the [Logs](./general.md) tab. The blocks follow in this order: **Search Settings**, **Logs and limits**, **Ignore list**, **Data masking**, **Export**. Changes apply immediately.\r
\r
---\r
\r
## Search Settings\r
\r
| Checkbox | Default |\r
| -------- | ------- |\r
| **Search by event name (title, component, store, URL)** | on |\r
| **Search by key (payload keys and changed paths)** | off |\r
| **Search by value (payload values)** | off |\r
\r
How a query matches is in [Working with logs](./general.md#search). If key and value are both off, name search stays on.\r
\r
---\r
\r
## Logs and limits\r
\r
### Logged events\r
\r
Each group has a checkbox: an unchecked group is not logged at all, and already logged events stay. All groups are on by default.\r
\r
| Group | Events |\r
| ----- | ------ |\r
| **Requests** | **Send request** and **Receive response** |\r
| **WebSocket** | **WebSocket open**, **WebSocket sent**, **WebSocket received** and **WebSocket closed** |\r
| **Props changes** | **Change props** |\r
| **Emits** | **Emit** |\r
| **Pinia changes** | **Change store** (when checked again, the store starts with a new **Store snapshot**) |\r
| **Store actions** | **Store action** |\r
| **Navigation** | **Navigation** |\r
| **Clicks** | **Click** |\r
| **JS errors** | **JS error** |\r
\r
The number beside each checkbox is how many events of that group are stored now. Its tooltip is **Currently stored**. **Requests** does not count **Receive response**, and the unit is **requests**. The other groups use **events**.\r
\r
### Data size\r
\r
| Setting | Default | Range | Meaning |\r
| ------- | ------- | ----- | ------- |\r
| **Memory budget** | 20 MB | 8 – 1024 MB | Total size of all buffered events (approximate serialized size). A network entry shared by a request and its response, and equal bodies, are counted once. A binary response counts as its format and size, not the file |\r
| **Limit event size** | on | — | On by default. Off: events are kept whole. The **Max event size** field is shown only while this is on |\r
| **Max event size** | 512 KB | 16 – 16 384 KB | Larger parts of an event (store snapshots, arguments, results) are dropped, network bodies are cut to this size |\r
\r
When the memory budget is reached, the log is cut at a **Navigation** and every event before it is removed. **Pinia** changes up to that cut are rebuilt into a **Store checkpoint**, so the remaining changes keep their **Before** / **After**; the previous base and the diffs it was built from are removed (see [How events are stored](./general.md#how-events-are-stored)). The last navigation is rewritten as a page snapshot, and if the log is still over the budget the oldest remaining events are removed. The newest event is always kept, even if it alone exceeds the budget. **Send request** and **Receive response** are also capped at **Maximum HTTP requests**, the same ring as HTTP rows on the Network tab (**Options → Network**, default **500**): the request and its response leave together. WebSocket log events are capped at **Maximum WebSocket events** (default **500**): open, sent, received and closed each count as one.\r
\r
The line under the bar is **Used {size} of {size} (approximate serialized size).** The bar turns orange at 90 % and above.\r
\r
A number outside the range is rounded and clamped to the nearest bound. A value that is not a number resets to the default. An empty field is treated as 0 and therefore becomes the minimum (8 MB or 16 KB). The new value is applied when the field is committed.\r
\r
**Defaults** on this block restores the group checkboxes, the budget, **Limit event size** and **Max event size**. It does not reset search, the ignore list, masking or **Compress report**.\r
\r
---\r
\r
## Ignore list\r
\r
Event groups excluded from logging. A group is one subject: the same request (method and path), the same component, the same store, and so on. Ignored groups are not recorded at all.\r
\r
Under the title: **These event groups are not recorded. Log again resumes one group.**\r
\r
| Column | Meaning |\r
| ------ | ------- |\r
| **Type** | The event label (**Send request**, **Change store**, **JS error**, and the rest) |\r
| **Object** | The stored group key: URL, component, store, message, and so on |\r
\r
The row menu is only **Log again**. **Log all again**, next to the title, clears the list and is disabled when it is empty. The empty table says *No ignored objects*. Clicking a row does nothing. There is no details card.\r
\r
The **ignored** indicator on the [Logs](./general.md) toolbar opens this table. It is hidden when the list is empty.\r
\r
---\r
\r
## Data masking {#data-masking}\r
\r
Values are masked **when an event is captured**, so they never reach the **Logs** view or exports.\r
\r
Under the title: **Values are masked when an event is captured, so they never reach the Logs view or exports.**\r
\r
Both checkboxes are labeled **Mask sensitive data**.\r
\r
* The first turns masking on. It is on by default. While it is off, the key list is dimmed and captured values are stored as they are.\r
* The second is directly under it and is disabled while the first is off. It is on by default. It masks **JWT** (\`[MASKED JWT]\`), **Bearer** / **Basic** / **Token** credentials (\`Bearer [MASKED]\`) and card numbers (\`[MASKED CARD]\`) inside any text of 8 characters or more. There is no separate label for that behavior.\r
\r
The key list header is **Key contains**. The empty table says *No keys — only value patterns are masked*. The add field placeholder is **Key fragment, e.g. accessCode**. **Add** or **Enter** trims the fragment. An empty value shows **Key cannot be empty**. The same fragment, ignoring case, shows **This key is already in the list**. The row menu is **Delete**. Clicking a row does nothing.\r
\r
Default keys: \`password\`, \`passwd\`, \`pwd\`, \`secret\`, \`token\`, \`authorization\`, \`cookie\`, \`apikey\`, \`sessionid\`, \`privatekey\`, \`creditcard\`, \`cardnumber\`, \`cvv\`, \`cvc\`, \`ssn\`, \`otp\`.\r
\r
Keys match case-insensitively and ignore separators (\`api_key\`, \`api-key\` and \`apiKey\` are the same). Fragments of **4 letters or fewer** must match a whole word, so \`pwd\` or \`otp\` do not mask unrelated keys.\r
\r
**Defaults**, next to the title, restores both checkboxes and the key list.\r
\r
Masked values of sensitive keys are replaced with \`[MASKED]\`. Card numbers are checked with the Luhn algorithm.\r
\r
---\r
\r
## Export {#export}\r
\r
**Compress report** is on by default. While the browser can compress, the helper says **The HTML report is several times smaller. Needs Chrome / Edge 80+, Firefox 113+ or Safari 16.4+.** The file then stores the event JSON as gzip in base64. In a browser that cannot compress, the checkbox is disabled and the helper says **Not supported in this browser. Needs Chrome / Edge 80+, Firefox 113+ or Safari 16.4+.** What the file contains is in [Export](./export.md).\r
\r
---\r
\r
## See also\r
\r
* [Working with logs](./general.md)\r
* [Export](./export.md)\r
* [Settings management](/options/settings_management)\r
`,y="---\r\ntitle: Advanced capture mode\r\n---\r\n\r\n# Advanced capture mode\r\n\r\nUnder **Options → Network** you can choose the **capture mode** for network traffic:\r\n\r\n| Mode | In the UI | What it means |\r\n| ---- | --------- | -------------- |\r\n| **Classic mode** | Radio **Classic mode**. While it is selected: *Captures standard headers available in the classic (non-extension) view.* | Same limits as in-page interception: headers and bodies are only what page scripts can read (including **CORS** rules for cross-origin). See [Working with requests](./general.md#display-limits). |\r\n| **Advanced mode** | Radio **Advanced mode**. While it is selected: *Captures full header data close to original DevTools output.* | The extension requests **`webRequest`** access and enriches the request details with the **full set** of request and response headers as seen by the browser for the exchange—not only the subset exposed to the page. |\r\n\r\n**Advanced mode** (pinning headers, **Header links**, Advanced-only header visibility options) is available **only in the Chrome / Edge extension**.  \r\n**Standalone** still runs without extended capture: the radios are disabled and the section says *Capture Mode is only available for the browser extension version.* The full header set via **`webRequest`** described below **is not available** there.\r\n\r\n---\r\n\r\n## What Advanced mode adds in the Network tab\r\n\r\n- **Request and response headers** in request details use the extended data (including headers not listed in `Access-Control-Expose-Headers`).\r\n- **Pinning header rows** — a header name can be pinned **to the top of the list** separately for **Request** and **Response**. Commands are in [Advanced headers](#advanced-headers).\r\n- **Header links** — for a given header name and request **Host**, open an external URL using a template; the **`{value}`** placeholder (and optional **value pipeline**) controls how the header text is inserted into the link. See [Header links](#header-links) below.\r\n\r\nThe **Header links** list, **Pinned headers** table, and **Advanced headers** options under **Options → Network** are shown **only when Advanced mode is enabled**, so Classic mode stays uncluttered.\r\n\r\n### Advanced headers {#advanced-headers}\r\n\r\n**Options → Network → Advanced headers** has three checkboxes, all on by default. They control headers that Advanced mode adds on top of what the page can read. A **pinned** name stays in that surface even when the checkbox is off.\r\n\r\n| Checkbox | Effect |\r\n| -------- | ------ |\r\n| **Show in details** | **Headers** on the request card |\r\n| **Include in Copy cURL** | **Copy cURL** |\r\n| **Include in Collection export** | **Export Collection** ([Export Collection](./export.md)) |\r\n\r\nIn Advanced mode the header row menu (right click or **⋮**) is:\r\n\r\n| Command | Effect |\r\n| ------- | ------ |\r\n| **Copy** | Copy the header value. Classic mode has this **Copy** column too, without the rest of the menu. |\r\n| **Pin** / **Unpin** | Pin that name to the top of **Request** or **Response** (**Pinned Request Headers** / **Pinned Response Headers**). |\r\n| **Create link** | No rule yet for this header on this host. The editor replaces the details panel. |\r\n| **Open link**, **Edit link**, **Delete link** | A rule for this header and host already exists. |\r\n\r\n### Pinned headers in Options\r\n\r\nThe table is sorted by header name, then by scope. Columns are **Header** and **Type** (**Request** or **Response**). An empty table says *No pinned headers. Add pins from the Network tab (header row menu).* There is no **Add** control. The only row action is **Delete**. Clicking a row does not open a card. Pins are added from the header row menu on the **Network** tab, described above.\r\n\r\n---\r\n\r\n## Header links\r\n\r\nEach rule defines:\r\n\r\n- **Header** — HTTP header name (matched **case-insensitively**);\r\n- **Host** — host of the request URL (normalized: no scheme or path, e.g. `api.example.com`);\r\n- **Link** — URL template; placeholders are resolved as described in **[Value placeholder and pipeline](#value-placeholder-and-pipelines)**.\r\n\r\nYou can create a rule from the **header row menu** on the **Network** tab (Advanced). In **Options** the **Header links** table groups rules by header name, ignoring case, and sorts those names. Columns are **Header** and **Rules** (how many hosts). An empty table says *No header links. Create one from the Network tab (Advanced) via a header row menu.* There is no **Add** control.\r\n\r\n**Delete** in the row menu removes every rule for that header name at once. A click opens **Header Link Details**: the header name, then **Host** and **Link** for each rule, and **Last updated** when a rule has a time. The pencil turns on editing. The header name stays fixed. **Add Rule** appends a row, **×** removes one row, **Remove all** clears the draft. **Save** keeps only rows that have both a host and a link. The host is lowercased, and a scheme or a path typed into it is stripped (`https://api.example.com/v1` is stored as `api.example.com`). Two rows with the same host: the later one is kept. A row with an empty host or an empty link is dropped. **Cancel** discards the draft. **Enter** in **Host** or **Link** saves. If the group is deleted while the card is open, the card says *This header link was removed.* Placeholders in **Link** are described in **[Value placeholder and pipeline](#value-placeholder-and-pipelines)**.\r\n\r\n### Value placeholder and pipeline {#value-placeholder-and-pipelines}\r\n\r\nInside the **Link** field you can use:\r\n\r\n- **`{value}`** — insert the header value exactly as shown on the request card (same as a pipeline with no steps).\r\n- **`{value|…}`** — run a **pipeline**: after `{value`, list steps separated by **`|`**; apply them **left → right**, then insert the result. Example: `{value|trim|urlencode}`.\r\n\r\nUse a **pipe** `|` between steps. The parser splits the chain at `|` only when the **next** segment starts with a **known operation** (see tables below). That way, a `|` **inside a regex** (e.g. alternation `a|b`) is usually fine, as long as the substring after a candidate split does not look like a new op.\r\n\r\nIf a step is invalid (e.g. bad regex), that step is skipped and the value is left unchanged for that step.\r\n\r\n#### No-argument operations\r\n\r\n| Op | Effect |\r\n| --- | --- |\r\n| `trim` | Trim leading/trailing whitespace. |\r\n| `lower` | Lowercase. |\r\n| `upper` | Uppercase. |\r\n| `urlencode` | `encodeURIComponent`-style encoding for use in URL query parts. |\r\n| `urldecode` | Decode URI component (`+` treated as space). Invalid escapes leave the value unchanged. |\r\n| `base64encode` / `base64decode` | Base64 of UTF-8 bytes. |\r\n| `hexencode` / `hexdecode` | Hex string ↔ UTF-8 bytes (`hexdecode` ignores whitespace). |\r\n| `md5` | MD5 hex digest of UTF-8 input (sync). |\r\n| `sha1` / `sha256` | SHA-1 / SHA-256 hex digest via **Web Crypto** (`crypto.subtle`). Requires a context where SubtleCrypto is available (e.g. **HTTPS** or extension pages); otherwise the digest step yields an empty string. |\r\n\r\n#### Regex and replacement\r\n\r\n| Op | Syntax | Notes |\r\n| --- | --- | --- |\r\n| `regex` | `regex:<pattern>` | `new RegExp(<pattern>)` (no flags in the syntax—add them inside the pattern if your engine supports it). Sets the **last match** for a following `replace`. On no match, the value becomes empty. |\r\n| `replace` | `replace:<template>` | After `replace:`, substitute `$1`, `$2`, … from the **last** `regex` match. If there was no match, result is empty. |\r\n| `replaceRegex` | `replaceRegex:<pattern>:<template>` | **Pattern** and **template** are split at the **last** `:` in the segment—so a `:` inside the pattern is awkward; prefer `regex` + `replace` instead. Uses `String.replace` with a `RegExp`. |\r\n| `match` | `match:<pattern>` | If the value matches, keep it; otherwise replace with empty string. |\r\n\r\n#### Strings and structure\r\n\r\n| Op | Syntax | Notes |\r\n| --- | --- | --- |\r\n| `replaceText` | `replaceText:<from>:<to>` | **From** / **to** use the **last** `:` in the payload as separator between `to` and everything before it (`from` may contain `:`). Global replace of all `from` occurrences. Empty `from` skips the step. |\r\n| `substring` | `substring:<start>` or `substring:<start>:<length>` | Same idea as `String.slice` / `substring`: with two numbers, length is a **character count** from `start`. |\r\n| `split` | `split:<delimiter>:<index>` | **Index** is the part after the **last** `:` (must be digits). **Delimiter** is everything before that `:` (may contain `:`). Empty part if index is out of range. |\r\n\r\n#### Conditions and defaults\r\n\r\n| Op | Syntax | Notes |\r\n| --- | --- | --- |\r\n| `default` | `default:<fallback>` | If the current value is exactly the **empty string** after previous steps, set it to `<fallback>`. To treat whitespace-only as empty, use `trim` first. |\r\n| `ifMatch` | `ifMatch:<pattern>:<ifTrue>:<ifFalse>` | **False** branch is after the **last** `:`; **true** branch is between the **second-to-last** and **last** `:`; **pattern** is everything before the **second-to-last** `:` (so colons inside branches are constrained by this rule). |\r\n\r\n### Examples\r\n\r\n```text\r\nhttps://trace.example.com/?id={value}\r\n```\r\n\r\n```text\r\nhttps://trace.example.com/?id={value|trim|urlencode}\r\n```\r\n\r\n```text\r\nhttps://trace.example.com/?t={value|regex:^Bearer\\s+(.+)$|replace:$1|urlencode}\r\n```\r\n\r\n```text\r\nhttps://trace.example.com/?t={value|default:unknown}\r\n```\r\n\r\nMultiple placeholders in one template are allowed; each `{value...}` block is resolved independently using the **same** header value.\r\n\r\n---\r\n\r\n## Quick recap\r\n\r\n- **Advanced mode** extends headers via **`webRequest`**; **Standalone** does not provide this mode.\r\n- **Classic mode** is the original “page-visible” header model.\r\n- **Pin** — separate for **Request** / **Response** lists. Pinned names stay visible when the Advanced header checkboxes above are off.\r\n- **Header links:** **Host** + **Link** template: **`{value}`** or pipeline **`{value|op|…}`** for the header value.\r\n",b=`---\r
title: Export Collection\r
---\r
\r
# Export Collection\r
\r
![Network, область заголовка (JPG)](/screenshots/Network_header.jpg)\r
\r
On the **Network** tab, captured requests can be saved as a **Postman collection** file (**JSON**, an API description format compatible with Postman and many other clients). This is useful for replaying flows, sharing them with teammates, or importing them into a separate testing tool.\r
\r
What appears in the list and possible data visibility limitations are described in [Working with requests](/network/general). In the inspector, **multipart** bodies are already shown as structured form fields; the export maps that shape into Postman-style **form-data** rather than a single opaque blob.\r
\r
---\r
\r
## Where to find the command\r
\r
**Export Collection** is located on the **Network** toolbar, next to **All** / **XHR** / **WS** (next to search and filters). On a narrow toolbar the switch and the button move together to the next line. **All** lists every row, **XHR** lists \`fetch\` / XHR, **WS** lists WebSocket. The export follows that switch for HTTP requests and always skips WebSocket.\r
\r
The tooltip indicates that the **currently filtered** HTTP requests will be exported.\r
\r
The button remains **disabled** while the filtered list has no HTTP request. With only WebSocket rows visible it stays disabled.\r
\r
---\r
\r
## What gets exported\r
\r
The file contains **only HTTP rows currently visible** in the table with **Search** and active search modes applied (path, method, status code, keys and values inside bodies, and so on). This is not necessarily the full request history: active filters restrict what enters the collection. **WebSocket** rows are omitted.\r
\r
If HTTP requests are ticked in the checkbox column, only the selected requests are exported; the button then shows **Export Collection (n)**. WebSocket rows cannot be ticked, and a range or select-all does not include them.\r
\r
For each included row, a separate request is created in the collection with:\r
\r
* **method** and **URL** (including address components and query string when present);\r
* **request headers** stored by the inspector (pseudo-headers starting with \`:\` are omitted; for **multipart** bodies the content-type header may be intentionally skipped to avoid conflicts with Postman **form-data** mode). In **Advanced mode**, headers that only the browser captured are included when **Include in Collection export** is on; pinned names are kept either way ([Advanced headers](./advanced.md#advanced-headers));\r
* **request body** when captured: raw text (including JSON syntax hints where applicable) or **form-data** fields, including file-part markers (binary files themselves are not attached — only names or placeholders are exported, as is typical when no real files are available).\r
\r
**Server responses** are **not included** — the export contains only the description of **outgoing** requests suitable for replay from a client.\r
\r
Collection item names follow the short request label shown in the Network list.\r
\r
---\r
\r
## Saved file\r
\r
After clicking **Export Collection**, the browser offers a **JSON** file download with a Postman-style filename (spaces in the default title are usually replaced with underscores).\r
\r
The file can be imported into **Postman** or opened in any editor to inspect its structure.\r
\r
---\r
\r
## Caveats\r
\r
* Only **headers and bodies the inspector was able to read** are included in the export (CORS limitations, truncated bodies, opaque binary content, and similar restrictions may affect output).\r
* Rows with **network errors** or partial data may still appear in the export if they remain visible after filtering — validate requests before reuse.\r
* **Replaying** requests from Postman may differ from browser behavior because of cookies, tokens, environment settings, and headers automatically added by the browser — manual adjustment after import may be required.\r
\r
---\r
\r
## See also\r
\r
* [Working with requests](/network/general)\r
* [Traffic interception](/network/traffic)\r
`,k=`---\r
title: Working with requests\r
---\r
\r
# Working with requests\r
\r
The **Network** tab shows network activity of the application at runtime.\r
\r
## Top toolbar\r
\r
![Network, область заголовка (JPG)](/screenshots/Network_header.jpg)\r
\r
### Search\r
\r
The search box supports multiple modes. The active criteria are chosen in **Search by** next to the input. The same options exist under **Options** for that tab so you can preset search types.\r
\r
| Mode            | Description                                          |\r
| --------------- | ---------------------------------------------------- |\r
| **Status code** | Search by response status code                       |\r
| **Method**      | Search by HTTP method                                |\r
| **Path**        | Search by URL or part of the path                    |\r
| **Name**        | Search by request name                               |\r
| **Key**         | Search by keys in **JSON** request/response bodies   |\r
| **Value**       | Search by values in **JSON** request/response bodies |\r
\r
\r
**Path** and **Method** are on by default. **Status code**, **Name**, **Key** and **Value** stay off until you enable them in **Search by** or under **Options → Network → Search Settings**. The checkboxes there are **Search by status code**, **Search by method**, **Search by path**, **Search by name**, **Search by key** and **Search by value**. If every one of them is off, a non-empty query matches nothing.\r
\r
On that screen the blocks follow in this order: **Search Settings**, **Request history**, **Capture mode**, then — only while **Advanced mode** is selected — **Advanced headers**, **Header links** and **Pinned headers**, then **Breakpoints Requests** and **Mocks Responses**. The lists are described in [Traffic interception](./traffic.md) and [Advanced capture mode](./advanced.md).\r
\r
The query is applied after **Search Debounce** (default **300** ms) and only once it reaches **Minimum Search Length** (default **2**). Both live under **Options → General → Search Parameters** and are shared with the other tabs ([Update settings](/options/update_settings)). A shorter query shows the full list.\r
\r
**Partial vs exact match.** If the query is **not** wrapped in quotes, **substring** matching is used across enabled modes (case-insensitive for text) — similar to **\`LIKE '%text%'\`**. **Exact** whole-string matching applies only when the **entire** query is wrapped in **double quotes** \`"..."\`.\r
\r
For key/value modes the body must parse as JSON; otherwise that part of the index stays empty. **Key** stores nested keys as dotted paths (\`user.id\`). On a WebSocket row, **Value** also searches the latest **30** text frames, each clipped to the first **1500** characters; JSON in those frames is indexed for **Key** and **Value** too. **Status code** matches the numeric status. A WebSocket row is **0** while it is connecting or the handshake failed, and **101** after that — **Open** and **Closed** are not status codes.\r
\r
### Status indicators\r
\r
The right side of the **Network** toolbar shows status chips. Some are **clickable**.\r
\r
| Item | Purpose |\r
| ---- | ------- |\r
| **N** or **N/M** | Row count after search and the **All** / **XHR** / **WS** switch. **M** is the total rows in the buffer when that count is smaller. |\r
| **pending** | Requests still in flight, including a WebSocket that is still connecting. |\r
| **bp** (highlighted, pulse) | Breakpoints waiting for UI action. Click selects the first such row. |\r
| **bp** (solid amber) | Count of active breakpoint rules. Click opens **Options → Network**, the **Breakpoints Requests** table. |\r
| **mock** | Active mock response rules. Click opens **Options → Network**, the **Mocks Responses** table. |\r
| **Paused** | Traffic logging to the list is paused. |\r
\r
When **breakpoint rules** or **mock response rules** are **suspended** globally (see below), the **bp** and **mock** chips keep their counts but use a **muted** style to show that those rules are **not** applied until you turn them back on.\r
\r
## Log controls\r
\r
### Breakpoint rules and mock responses (global) {#breakpoint-rules-and-mock-responses-global}\r
\r
Next to **Pause recording** and **Clear**, the toolbar has two **icon** controls that apply to **all** configured rules of each type (without deleting them):\r
\r
| Control | Icon (when active) | Meaning |\r
| ------- | ------------------ | ------- |\r
| **Breakpoint rules** | Pause / stop circle (**amber** when rules are on) | **On:** active breakpoint rules can pause matching requests. **Click:** **suspend** breakpoints — rules stay in **Options → Network → Breakpoints Requests**, but no request is held until you enable again. Tooltip: *Breakpoints on (click to suspend)* / *Breakpoints suspended (click to enable)*. |\r
| **Mock responses** | Shuffle (**purple** when mocks are on) | **On:** active mock rules can short-circuit matching requests. **Click:** **suspend** mocks — rules stay in **Options → Network → Mocks Responses**, but the real network runs until you enable again. Tooltip: *Mock responses on (click to suspend)* / *Mock responses suspended (click to enable)*. |\r
\r
The same switches exist as **Enable breakpoint rules** and **Enable mock responses** next to the corresponding lists in **Options → Network**; changing either place updates the other.\r
\r
**Note:** Suspending rules is **not** the same as **Pause recording**. Pause removes the interceptor from the page and stops logging; the global switches only disable **breakpoint** or **mock** handling while the interceptor remains (unless you also pause recording). Details: [Traffic interception](./traffic.md).\r
\r
### Pause\r
\r
**Pause** temporarily stops recording into the **Network** list.\r
\r
While paused:\r
\r
* new requests **do not appear** in Vue Inspector **Network** until you resume;\r
* the interceptor **is removed**: the page uses native \`fetch\`, \`XMLHttpRequest\` and \`WebSocket\` again (no inspector substitution).\r
\r
Implications:\r
\r
* in the **built-in Network** tab of DevTools the same requests show the **original initiator** (your app code), not the injected script (\`injected.js\`, etc.);\r
* while paused, interception features **do not apply** to new calls: **Mock response** and **Breakpoint** (see [traffic interception](./traffic.md)). After **Resume**, interception and rules are active again.\r
\r
A call that had already entered the inspector wrapper before **Pause** still finishes: its row updates, and a breakpoint this call has already reached still waits. Calls that start after **Pause** use the native APIs and are neither logged nor intercepted.\r
\r
### Clear\r
\r
Clears accumulated rows next to **Pause**.\r
\r
### Export Collection\r
\r
**All** / **XHR** / **WS**, next to **Export Collection**, limits the table to every row, to \`fetch\` / XHR, or to WebSocket. **All** is the default. The last choice is kept between sessions. The switch does not remove rows from the buffer. On a narrow toolbar the switch and **Export Collection** move together to the next line.\r
\r
**Export Collection** downloads a **Postman collection** (**JSON**): the current **filtered** HTTP list, or only the ticked HTTP requests. **WebSocket** rows are left out of the file. Their checkboxes stay disabled, and select all and a **Shift** range skip them. On **WS** the button stays disabled (see [Export Collection](./export.md)).\r
\r
## Work area\r
\r
![Network, полноэкранный режим](/screenshots/Network_full_screen.jpg)\r
\r
### Request list\r
\r
The left side lists captured requests, **newest first**. Until anything is captured the table says **No network requests captured yet**.\r
\r
Columns come from the picker in the table header. **Name** and **Path** cannot both be hidden. **Name** is hidden by default; the other columns are shown.\r
\r
| Column | What it shows |\r
| ------ | ------------- |\r
| **Status** | HTTP status. A row still in flight shows **⏳**. A failed row shows **✗**. The error text is drawn under **Path** when that column is visible. |\r
| **Method** | HTTP method, or **WS** for a socket. |\r
| **Name** | Short label taken from the URL. |\r
| **Path** | URL path. |\r
| **Time** | Duration, or **...** while the row is pending. |\r
| **Size** | Payload size, or **...** while the row is pending. |\r
\r
A pending row is dimmed. A row held on a breakpoint has an amber background. A row that only matches a breakpoint rule has an amber bar on the left. A row that matches a mock has a purple bar, and a purple background when that row is selected. While breakpoint or mock rules are suspended globally, those marks are muted.\r
\r
The first column contains checkboxes for **Export Collection** (Postman **JSON**):\r
\r
| Action | Result |\r
| ------ | ------ |\r
| Click a checkbox | Select / unselect a request |\r
| **Shift** + click | Select a range from the last clicked row |\r
| **Ctrl / Cmd** + click on a row | Toggle a row without opening details |\r
| Header checkbox | Select all HTTP rows / clear selection |\r
\r
A **WebSocket** row cannot be ticked.\r
\r
The row menu (right click or **⋮**) on an HTTP row:\r
\r
| Command | When it appears |\r
| ------- | --------------- |\r
| **Copy cURL** | Always. The same action is the **Copy cURL** button in the details header when the panel is at least **1000** px wide (tooltip: *Copy as cURL command (for Postman)*). On a narrower panel it stays in the **⋮** menu. Which Advanced-only headers are included is set under [Advanced capture mode](./advanced.md#advanced-headers). |\r
| **Ask AI** | Always. See below. |\r
| **Breakpoint Request** / **Rewrite Breakpoint** | **Rewrite** when the row already matches a breakpoint rule. Opens the rule form ([Traffic interception](./traffic.md)). |\r
| **Mock Response** / **Rewrite Mock** | **Rewrite** when the row already matches a mock. |\r
| **Enable** / **Disable Breakpoint**, **Delete Breakpoint** | A breakpoint rule matches this row. |\r
| **Enable** / **Disable Mock**, **Delete Mock** | A mock rule matches this row. |\r
\r
A WebSocket row’s menu contains only **Ask AI**.\r
\r
**Ask AI** (row menu and the details header menu) attaches the request to a question for the assistant. The **AI** tab opens with a chip above the input that shows the method and name: **×** removes it from the question. Type a question, or send the chip without one. The assistant gets the full request and response. When the request is in **Logs**, it gets its event id \`#N\`. Values are masked and cut by the AI settings.\r
\r
### Request details\r
\r
Opening a row shows exchange details:\r
\r
* **Headers** — request and response headers;\r
* **Params** — query string pairs;\r
* **Request** — request body;\r
* **Response** — response body;\r
* **Messages** — for a WebSocket row, each sent and received message.\r
\r
With nothing selected the panel says **Select a request to see details**. The section you last opened is kept for this inspector session and is not written to settings. Until you switch sections, an HTTP row opens on **Response**. A WebSocket row uses **Messages** unless **Headers** was the last section that applies. JSON bodies use the [JSON editor](/options/json_mode). Text shorter than **200 KB** is pretty-printed when it is JSON; a longer body is shown as captured.\r
\r
**Back** and **Escape** close the details. On a paused breakpoint they release the pause and send the original request ([Traffic interception](./traffic.md)). While a breakpoint is waiting, **Apply** sends the edited request and the card shows a **Breakpoint** badge. A changed method or URL is drawn in amber.\r
\r
**GET** and **HEAD** show that the method cannot have a body. A body cut by the size limit shows **Truncated**. Until a response arrives, **Response** says **Waiting for response...**. A failed exchange shows the error text there instead of a body. Each header value has **Copy**. In Advanced mode the header row menu adds pin and link commands ([Advanced capture mode](./advanced.md#advanced-headers)).\r
\r
For **\`multipart/form-data\`** bodies captured as structured data, **Request** is shown as a **read-only table**: field key, **Text** or **File**, cell value (text fields as-is; file fields show name and size, or **\`(binary)\`** when the original bytes are not kept as displayable text). **Copy** copies the visible text or the file name, depending on the row.\r
\r
## Display limits\r
\r
### Reading limits\r
\r
Vue Inspector only shows headers and bodies **visible to page JavaScript** after the request completes.\r
\r
For **cross-origin** responses browsers apply **CORS**: not every response header is exposed unless listed in **\`Access-Control-Expose-Headers\`**.  \r
For example, if \`X-Request-Id\` is missing from:\r
\r
\`\`\`http\r
Access-Control-Expose-Headers: X-Request-Id\r
\`\`\`\r
\r
(or a list that includes it), the page may not see it in \`response.headers\` — and Network will not show it, even if the browser’s native Network tab does.\r
\r
On **same-origin** requests headers are usually available unless another policy hides them.\r
\r
In the **Vue Inspector extension** for Chrome / Edge, **Advanced mode** (capture setting under **Options → Network**) can enrich request and response headers with browser-level data beyond what the page is allowed to read. For details, header pinning, **Header links**, and related options, see [Advanced capture mode](./advanced.md).\r
\r
Very large bodies may be truncated (roughly **20 MB** captured text in code).\r
\r
A binary response shows the content type, the size and a **Binary** badge, for example \`image/jpeg (986.2 KB)\`. The file itself is not stored. A binary request body shows the same badge and the text *Binary content cannot be displayed*. Durations under one second are shown with two digits after the decimal point (\`635.90 ms\`).\r
\r
### Storage cap\r
\r
The Network list keeps HTTP rows and WebSocket rows on separate rings. Each default is **500**, and each is changed under **Options → Network → Request history** (50–5000): **Maximum HTTP requests** and **Maximum WebSocket events**. When the field changes, the number is rounded and clamped into that range. A value that is not a number is reset to **500**. The new caps apply at once to the Network list and to Logs.\r
\r
When a cap is reached, the oldest rows of that kind are dropped. Logs keeps the same number of HTTP requests (a request leaves together with its response) and the same number of WebSocket events (open, sent, received and closed each count as one). Both rings are separate from the memory budget.\r
\r
## How it works\r
\r
### When interception starts\r
\r
The network module loads with the rest of Vue Inspector in the **tab context** when you open the inspector overlay or attach the DevTools panel. Until that script runs, \`fetch\` / \`XMLHttpRequest\` are not patched. A small page script runs at document start and remembers WebSocket objects the page opens, so **Network** can attach to sockets that are already connected when the inspector starts.\r
\r
The buffer lives in the page after load; **Network** reads it whenever the panel is open. Without reload, history remains available when you open **Network** later (subject to the request limit above).\r
\r
### What is monitored\r
\r
Calls through:\r
\r
* **\`fetch\`**\r
* **\`XMLHttpRequest\` (XHR)**\r
* **\`WebSocket\`** — one row per connection, including a socket that was already open when the inspector started. The method column shows **WS**. In the table an open socket shows **Open**, one that is still connecting shows **⏳**, a failed handshake shows **✗**, and a closed socket shows its close code. Code **1005** and a close without a code show **Closed**. A close code other than **1000**, **1001** or **1005**, and a row with an error, is shown in red. The details header uses **Open**, **Connecting**, **Closed**, or **Closed** plus the code. **Headers** in the extension shows the HTTP upgrade recorded by the browser. Bookmark mode cannot see that exchange: the tab shows **Host**, **Origin**, **User-Agent**, **Connection**, **Upgrade** and **Sec-WebSocket-Version**, plus **Sec-WebSocket-Protocol** and **Sec-WebSocket-Extensions** when the socket reports them. **Sec-WebSocket-Key**, **Sec-WebSocket-Accept** and **Cookie** stay unavailable. **Messages** lists each sent and received frame with its time, direction and size, newest at the bottom. Text is shown as text. One JSON value is formatted with indents; several JSON values in one frame, separated by newlines, are formatted as separate objects. Binary is a short hex preview. The row keeps the latest **200** messages, and a single message is stored up to **64 KB**. **Sent** sends the composed text and is enabled only while the socket is **open**. **Received** delivers that text to the page and is enabled until the socket is **closed**; such a frame is marked **Mock**. Text frames have **Copy**. If older frames were discarded, the bar shows **Earlier messages dropped:** and the count. The negotiated protocol and the close reason are shown above the list when the socket reports them. There is no **Params** tab. Breakpoint, mock and **Copy cURL** stay on \`fetch\` / XHR; the row menu has only **Ask AI**. **Logs** records **WebSocket open**, **WebSocket sent**, **WebSocket received** and **WebSocket closed** as separate events that share one connection. A JSON frame is shown formatted, including several JSON values separated by newlines in one frame. Those types are in the **Type** filter. When the protocol can be recognized as Centrifuge and the close code means the client will not reconnect (for example **3501**), the close event says **No automatic reconnect** and keeps the reason. Typing \`{}\` for such a socket shows *This frame may trigger a protocol error and disconnect the WebSocket.* **Sent** and **Received** still send that text.\r
\r
Not captured, among others:\r
\r
* other APIs (\`navigator.sendBeacon\`, \`EventSource\`, \`<img>\` / \`<script>\` loads without XHR);\r
* **OPTIONS** preflights (filtered out);\r
* extension URLs (\`chrome-extension://\`, \`moz-extension://\`, …).\r
\r
Each HTTP row records the initiator type: **fetch** or **xhr**. A WebSocket row records **websocket**.\r
\r
### Interception model\r
\r
Unlike the browser **Network** DevTools tab (engine-level), Vue Inspector runs **in the page**: it wraps global \`fetch\` and XHR methods, performs the real network call, then reads whatever the response object exposes to the page (headers, body, status, timing).\r
\r
Simplified \`fetch\` idea:\r
\r
\`\`\`js\r
// Illustration: after the real request, headers come from response.headers.\r
// Names are limited by the browser (including CORS), not “all” wire headers.\r
window.fetch = async function patchedFetch(input, init) {\r
  const response = await originalFetch.call(window, input, init)\r
  const headersForUi = []\r
  response.headers.forEach((value, name) => {\r
    headersForUi.push({ name, value })\r
  })\r
  // …send metadata and body to the inspector UI…\r
  return response\r
}\r
\`\`\`\r
`,S=`---\r
title: Traffic interception\r
---\r
\r
# Breakpoints and mock responses\r
\r
The **Network** tab and **Options → Network** provide two interception mechanisms:\r
\r
* **Breakpoint** — pause an outgoing request **before it hits the network**, edit parameters, then continue;\r
* **Mock response** — return a crafted response **without calling the server**.\r
\r
Both apply to **\`fetch\`** and **\`XMLHttpRequest\`** on the current page. WebSocket rows are observed only: breakpoint and mock rules do not apply to them.\r
\r
On a narrow panel the list and the request details share one screen. Saving a breakpoint or mock, or leaving that form with the back button, closes the details. On a wide panel the details stay open.\r
\r
You can **suspend all breakpoint rules** or **all mock rules** globally from the **Network** toolbar or via **Enable breakpoint rules** / **Enable mock responses** in **Options → Network** — rules remain saved but are not applied until re-enabled. See [Working with requests](/network/general#breakpoint-rules-and-mock-responses-global).\r
\r
General interception limits (page context, CORS, scope) are described in [Working with requests](/network/general).\r
\r
---\r
\r
## Breakpoints\r
\r
![Breakpoint](/screenshots/Breakpoint.jpg)\r
\r
### Purpose\r
\r
A breakpoint pauses an outbound request **before it is sent**.\r
\r
When the rule matches ([how a rule matches](#how-a-rule-matches)):\r
\r
* the request is held;\r
* the UI lets you edit parameters;\r
* **Apply** sends the request with your changes;\r
* **Back** or **Escape** releases the pause and sends the **original** request. The call is not aborted.\r
\r
Interception happens after the app built the request but before native send.\r
\r
### What you can change\r
\r
Before continuing you can edit:\r
\r
* HTTP method;\r
* URL (scheme, host, path, query);\r
* headers;\r
* body.\r
\r
After **Apply** the request goes out in the modified form.\r
\r
### Request body: raw and form-data (breakpoint)\r
\r
For the paused request, the body editor can use **Raw** (single text area) or **Form-data** (rows analogous to the read-only **Network** details table).\r
\r
### Form-data mode\r
\r
In **Form-data** mode, each row contains:\r
\r
* a **key**;\r
* a value type (**Text** or **File**);\r
* the value.\r
\r
For **File** rows, **Browse** lets you pick a file from disk. The chosen file is added to the draft, typically as a **\`data:\`** URI.\r
\r
### File sources for File fields\r
\r
For **File** rows, the dropdown lists:\r
\r
* **Original** — restore the file that was already part of this request (equivalent to the original **\`(binary)\`** for as long as the current pause still has the original \`FormData\`);\r
* **Saved Files** entries under **Options → General**;\r
* **wallpapers** (background media) from **Customize** — same shared media store as panel styling.\r
\r
### Auto-saving files selected via Browse\r
\r
**Auto-save new files selected via Browse** (**Options → General → Saved Files**) controls whether files picked in this editor are auto-saved.\r
\r
When the option is on:\r
\r
* the file is copied to **Saved Files**;\r
* that happens only if there is not already an entry with the same **name + size** pair.\r
\r
Storage limits follow [Customize](/options/customize):\r
\r
* the **extension** uses **IndexedDB**;\r
* **standalone** enforces a **30 MB** cap.\r
\r
### How data is applied after you continue\r
\r
After you continue, the injected script builds a new **\`FormData\`** object:\r
\r
* text values are appended as normal fields;\r
* **\`data:\`** values are turned into file parts;\r
* **\`(binary)\`** restores the original **File** from the captured request for as long as that source data is still available.\r
\r
### File restoration limits\r
\r
If the value is still:\r
\r
* a **\`blob:\`** URL;\r
* or a **\`__fileId:\`…** reference,\r
\r
the page cannot recover the file contents on its own.\r
\r
In that case an **empty** placeholder is sent for that part and the console emits a **warning**.\r
\r
To avoid that, pick the file again with **Browse** or select a saved file from the list.\r
\r
### Where to configure\r
\r
* **Network** — **Breakpoint Request** or **Rewrite Breakpoint** on a captured request.\r
* **Options → Network → Breakpoints Requests** — manage the rule list.\r
* **Network toolbar** (breakpoint icon) or **Enable breakpoint rules** in **Options** — turn **all** breakpoint handling on or off without deleting rules (see [Working with requests](/network/general#breakpoint-rules-and-mock-responses-global)).\r
\r
### Breakpoints Requests in Options\r
\r
The table has no **Add** control. An empty list says *No breakpoints configured. Set breakpoints from the Network tab.*\r
\r
| Column | What it shows |\r
| ------ | ------------- |\r
| **Description** | The rule note, or the URL pattern when the note is empty. |\r
| **Status** | **Active** or **Off**. |\r
\r
Active rows are listed first. An **Off** row is dimmed and is not counted by the **bp** chip. The row menu (right click or **⋮**) is **Edit**, **Enable** / **Disable** and **Delete**. **Disable** sets the row to **Off** without deleting it. A rule pauses traffic only when that row is **Active** and **Enable breakpoint rules** is on. How a pattern matches is in [How a rule matches](#how-a-rule-matches).\r
\r
A click opens **Breakpoint Details**: the URL pattern, the method (**All** when it is empty), **Active** or **Disabled**, scheme, host, port, path, query and the time the rule was created. **Edit** on that card, or **Edit** in the row menu, opens the same form as on the Network tab. The panel ring is amber. **Save Breakpoint** writes the rule back and leaves it **Active** or **Off**. **Back** or **Escape** closes the form without saving. Below **1000** px the card covers the settings list until you go back.\r
\r
With nothing selected the panel says *Select an item to see details*. If the rule was removed while the card is open, it says *Item no longer exists*.\r
\r
### How a rule matches {#how-a-rule-matches}\r
\r
WebSocket rows never match. The first enabled rule in the active list that fits is the one applied. Mocks use the same URL rules.\r
\r
| Field | Match |\r
| ----- | ----- |\r
| **Scheme** | Compared with the request scheme when the field is set, including case (the form fills \`https\` or \`http\` from the URL). The colored bar in the list ignores scheme case; the pause itself does not. |\r
| **Host** | Required to save the form. Exact hostname; \`*\` is a wildcard (\`*.example.com\`). Case is ignored. An empty stored host matches any host. |\r
| **Port** | Exact when set. A URL with no port is treated as **443** for \`https\` and **80** for \`http\`. |\r
| **Path** | Prefix of the pathname when set, so \`/api\` matches \`/api/users\`. \`*\` is a wildcard. Case is ignored. |\r
| **Query** | Optional. The query string without \`?\` must contain the pattern. \`*\` is a wildcard. A request with no query does not match a query pattern. |\r
| **Method** | Empty matches every method (the breakpoint field placeholder is **All**). A filled method must match; case is ignored. |\r
\r
A rule saved from **Network** pauses **before the request is sent**.\r
\r
### Behavior\r
\r
When a request hits an active breakpoint rule the UI focuses editing:\r
\r
* the breakpoint card opens on **Request** (a **URL** tab edits method, scheme, host and path);\r
* the view may switch to **Network**;\r
* a collapsed inspector iframe expands automatically.\r
\r
The details frame uses an amber ring while rules are enabled, and a muted ring while breakpoint rules are suspended.\r
\r
Until you press **Apply** or leave with **Back** / **Escape**, the request stays paused.\r
\r
## Mock responses\r
\r
![Моки запросов](/screenshots/Mock.jpg)\r
\r
### Purpose\r
\r
Mock fully replaces a network call with a local response.\r
\r
When a rule matches:\r
\r
* no server round-trip;\r
* a synthetic response is built;\r
* the page receives it like a normal HTTP response.\r
\r
### What a mock can set\r
\r
* **status** and **statusText**;\r
* **headers**;\r
* **body**;\r
* **delay** before resolving.\r
\r
### Where to configure\r
\r
* **Network** — **Mock Response** or **Rewrite Mock** on a request row. URL matching is the same as for [breakpoints](#how-a-rule-matches). An empty method matches every method. **Host** is required. **Status** must be from **100** to **599**. The form opens on **Response** and also has **URL Matching** and **Headers**.\r
* **Options → Network → Mocks Responses** — manage rules.\r
* **Network toolbar** (mock icon) or **Enable mock responses** in **Options** — turn **all** mock handling on or off without deleting rules (see [Working with requests](/network/general#breakpoint-rules-and-mock-responses-global)).\r
\r
### Mocks Responses in Options\r
\r
The table has no **Add** control. An empty list says *No mocks configured. Click "Mock Response" on any request in the Network tab.*\r
\r
| Column | What it shows |\r
| ------ | ------------- |\r
| **Description** | The rule note, or the URL pattern when the note is empty. An empty scheme, host or path is shown as \`*\`. |\r
| **Code** | Status number. **2xx** is green, **4xx** orange, **5xx** red. |\r
| **Delay** | \`Nms\`, or **-** when there is no delay. |\r
| **Status** | **Active** or **Off**. |\r
\r
Active rows are listed first. An **Off** row is dimmed and is not counted by the **mock** chip. The row menu is **Edit**, **Enable** / **Disable** and **Delete**. A mock runs only when the row is **Active** and **Enable mock responses** is on.\r
\r
A click opens **Mock Details**: the URL pattern, status and status text, delay (**None** when unset), state **Active** or **Disabled**, headers, body (\`(empty)\` when the body is an empty string), description and the time the rule was created. **Edit** opens the same mock form as on the Network tab. The panel ring is purple. Saving keeps the rule **Active** or **Off**. **Back** or **Escape** closes the form without saving. Below **1000** px the card covers the settings list.\r
\r
### Behavior\r
\r
If mock matches:\r
\r
* the real request is not sent;\r
* breakpoint does not apply for that call.\r
\r
If the synthetic response cannot be built, the real request is sent and the page console logs the error. The details frame uses a purple ring while the mock form is open and rules are enabled, and a muted ring while mock rules are suspended.\r
\r
Order of evaluation:\r
\r
1. mock first;\r
2. if no mock — breakpoint;\r
3. otherwise normal network.\r
\r
Mock wins over breakpoint.\r
\r
---\r
\r
## Breakpoint vs mock\r
\r
| Mechanism | Network round-trip | Can change request | Can change response |\r
|-----------|-------------------|--------------------|---------------------|\r
| Breakpoint | Yes | Yes | No |\r
| Mock response | No | No | Yes |\r
\r
---\r
\r
## Limits\r
\r
Both work only for:\r
\r
* **fetch**\r
* **XMLHttpRequest**\r
\r
Not intercepted:\r
\r
* \`<img>\`, \`<script>\`, \`<link>\` loads;\r
* service workers outside this layer;\r
* native browser calls outside page JS.\r
\r
**OPTIONS (preflight)** requests are not part of interception.\r
\r
---\r
\r
## Compared to Charles Proxy\r
\r
**Charles** (and similar **system / external proxies**: Fiddler, mitmproxy, …) sits **between client and server** at the OS or app level:\r
\r
* sees traffic **beyond the browser** (mobile apps, CLI, other tools if proxied);\r
* **HTTPS** typically needs a trusted root and **SSL Proxying** (TLS termination);\r
* **Breakpoints** and **Map Local / Remote** apply to **all** matching connections **on that channel**.\r
\r
**Vue Inspector** runs **inside the browser tab**: it patches **\`fetch\`** and **\`XMLHttpRequest\`**.\r
\r
| Aspect | Charles (typical) | Vue Inspector |\r
| ------ | ----------------- | ------------- |\r
| Level | Proxy / out-of-process | JS in the page |\r
| Scope | Many clients, HTTP(S) through proxy | This document only: **fetch** and **XHR** |\r
| HTTPS | Custom trust, TLS break | No extra TLS break — the app already sees responses in JS |\r
| SW / native requests | Often visible on the path | Not covered here |\r
| SPA convenience | Proxy + certs setup | Enable rules in the inspector for the current site |\r
\r
In **intent**, Inspector breakpoints/mocks resemble Charles (**pause / fake a response**); in **placement** it is a **page-level devtool**, not a network proxy.\r
\r
## See also\r
\r
* [Working with requests](/network/general)\r
* [Export collections](/network/export)\r
`,T=`---\r
title: About\r
---\r
\r
# About\r
\r
**Options → About** is the section labeled **About**. It does not change inspector settings.\r
\r
## Vue Inspector\r
\r
The text is: **A DevTools extension for inspecting Vue.js applications — components, props, Pinia stores, and network requests.**\r
\r
**Version** shows the extension version. If the manifest has no version, or the version is exactly \`1.0.0\`, standalone shows \`standalone_latest\` and the extension shows \`unknown\`.\r
\r
## Actions\r
\r
**Release notes** is always shown. In the extension it loads the GitHub release whose tag is the current version. In standalone it loads the latest release. While it loads, the button is disabled.\r
\r
**Check for updates** is shown only in the extension. It loads the latest release and compares that tag with the manifest version. A missing manifest version is compared as \`0.0.0\`. A newer tag opens **Update Available**. The same or an older tag opens **Up to Date**.\r
\r
The card closes with Back or Escape.\r
\r
| Card | What it shows |\r
| ---- | ------------- |\r
| **Release Notes** | **Version** and the notes. An empty note is **No release notes available.** |\r
| **Update Available** | **Download new version** and the version, then **What's New**. **Ignore** remembers this version so the update toast skips it until a different version is published. **Download** saves the first file attached to the release and is disabled when there is no file |\r
| **Up to Date** | **You're up to date!** and **Version … is the latest.** Then **Current Release Notes** when the release has notes |\r
\r
A failed request shows the error in the card. The messages are **Could not determine current version.**, **No release data available.**, **Failed to fetch release notes.**, **Failed to check for updates.**, **Release not found.**, **GitHub API rate limit exceeded. Resets at …**, **GitHub API error:** and the status, or **Network error**.\r
\r
## Links\r
\r
**GitHub** opens [https://github.com/FirsakovAE/qa-tools](https://github.com/FirsakovAE/qa-tools). **Docs** opens [https://vue-inspector.pages.dev/docs/](https://vue-inspector.pages.dev/docs/).\r
\r
## Footer\r
\r
**© 2026 FirsakovAE**\r
\r
**GNU General Public License v3.0** opens [https://www.gnu.org/licenses/gpl-3.0.html](https://www.gnu.org/licenses/gpl-3.0.html).\r
\r
## See also\r
\r
* [Release notes](/releases/history)\r
* [Display modes](/options/display_mode)\r
`,x=`---\r
title: Auto run\r
---\r
\r
# Auto run\r
\r
> **Extension only (Chrome / Edge).** The **Auto Run** block in **Options → General** is **hidden** in **standalone**: a bookmark has no background extension process to decide when to show the panel.\r
\r
**Auto Run** controls **when** the overlay **pill** appears on sites in **overlay** mode. This is **not** the component **blacklist** on **Props** — here we only filter **site origins** (scheme, host, port). Under the title the text is **Enable auto run application**. The only checkbox is **Enable whitelist mode**. There is no switch that turns the lists off.\r
\r
---\r
\r
## Basics\r
\r
Rules inspect the page **origin** (scheme, host, port; path is ignored). The placeholder is \`e.g. https://app.example/ or *localhost*\`.\r
\r
A full \`http\` or \`https\` URL is compared by origin, ignoring case. The path is dropped. A pattern that contains \`*\` is matched against the whole origin, ignoring case: \`*\` is any substring, and the pattern must cover the whole origin. A pattern with no \`*\` and no scheme must equal the whole origin, so \`localhost\` does not match \`http://localhost:5173\`. Use \`*localhost*\`.\r
\r
Empty input and a pattern already in that list are ignored, with no message. Empty lists impose no restriction until you add rows (or enable whitelist mode, below).\r
\r
The overlay still **won’t** inject on pages the extension treats as **static without Vue** (separate heuristic). Lists don’t bypass that — see the extension **popup** section.\r
\r
---\r
\r
## Site Blacklist\r
\r
**Site Blacklist** — origins/patterns where the pill **must not** auto-show.\r
\r
* Add via the field and **Add**, or Enter. The columns are **Name** and **Added**. **Added** is the date only.\r
* An empty list says **No site in blacklist**.\r
* Click a row to open **Site Blacklist Details**. The menu is **Edit** and **Delete**.\r
* **Edit** uses the field **Pattern** (placeholder **Origin pattern**). **Save** is disabled while it is blank. The same pattern already on another row is ignored. **Added** in the card is the date and time. Back or Escape closes the card.\r
* If the current origin **matches any** blacklist row, auto-run overlay is off for that tab.\r
\r
Blacklist can combine with whitelist: whitelist is evaluated first when active and non-empty.\r
\r
---\r
\r
## Site Whitelist and “whitelist mode”\r
\r
**Enable whitelist mode** shows **Site Whitelist**. The warning on that block is: **When the whitelist is not empty, the application will only run when the page origin (scheme, host including www, port) matches a pattern.**\r
\r
* While the whitelist is **empty**, mode is effectively open — only blacklist (if any) applies.\r
* Once the whitelist has **at least one** row, auto overlay is **only** allowed on matching origins; everything else is denied **before** blacklist trims further.\r
* An empty list says **No site in whitelist**. A row opens **Site Whitelist Details**. Add, edit, and delete work like the blacklist. The same pattern in that list is ignored.\r
\r
So a **non-empty whitelist** defines “where yes”, **blacklist** subtracts exceptions.\r
\r
---\r
\r
## Extension popup — escape hatch\r
\r
![Всплывающее окно](/screenshots/popup.jpg)\r
\r
The extension icon **popup** exposes two actions (UI labels in English: **Forced Launch**, **Reset Settings**).\r
\r
**Forced Launch** injects the inspector on the **active tab**, **ignoring** Auto Run lists and the static-site heuristic. Use when lists block all sites or **Options** is unreachable.\r
\r
**Reset Settings** performs a **full wipe** of saved inspector settings (Auto Run, theming, favorites, etc.). [Options → AI](/ai/settings) stays. Last resort if configuration locks you out — there is **no** undo without a backup export.\r
\r
If you rely on a strict whitelist, keep at least one URL you use to open **Options**, or remember **Forced Launch** / **Reset Settings**.\r
\r
---\r
\r
## See also\r
\r
* [Installation → Where settings are stored](/install#storage)\r
* [Browser extension](/extension)\r
`,A=`---\r
title: Customize\r
---\r
\r
# Customize\r
\r
![Персонализация](/screenshots/Customize.jpg)\r
\r
**Options → General → Customize** controls the main inspector look: theme, background media, and how it is displayed. You style the **tool**, not the site content.\r
\r
---\r
\r
## Extension vs standalone\r
\r
Fields (**theme**, **file / URL**, opacity, blur, position, scale) match. What differs is **where file bytes go** and **whether a total quota applies**.\r
\r
| | **Extension (Chrome / Edge)** | **Standalone** |\r
|---|------------------------------|----------------|\r
| **Where uploads live** | Media copies in extension **IndexedDB** (separate stores for wallpaper and saved files). | Media goes into the app’s **unified local store** (central quota). |\r
| **Size limit** | No app-enforced “N MB for media”; real cap is **IndexedDB / storage quota** for the extension profile. | **Hard 30 MB** total for decorative media in standalone storage — saves are blocked if the new total would exceed (error like “Media limit exceeded”). |\r
| **Usage meter** | The **X MB / 30 MB** counter is not shown. | Under **Saved Files**, **N.N MB / 30 MB**. The bar is yellow from **70%** and red from **90%**. |\r
\r
**URL backgrounds** do not count like uploaded files in local quota, but for offline predictability local files within quota are often simpler (in standalone respect **30 MB** total).\r
\r
---\r
\r
## Theme\r
\r
![Персонализация: селекторы](/screenshots/Customize_selectors.jpg)\r
\r
The icon button next to the current image name switches the inspector theme. The default is dark. The tooltip is **Switch to light theme** or **Switch to dark theme**.\r
\r
---\r
\r
## Background (Image)\r
\r
**Image** sets the panel background. The current name is shown next to **Change background**. With nothing chosen, that name is **Night Forest**.\r
\r
* **File** — local asset via **Browse** or previously saved copies (extension: IndexedDB; standalone: unified 30 MB store — table above). Presets: [Settings management](/options/settings_management).\r
* **Link** — URL to media.\r
\r
Supported: **still images**, animated **GIF**, **MP4** video backgrounds.\r
\r
---\r
\r
## Background rendering\r
\r
| Control | Role |\r
| ------- | ---- |\r
| **Image Opacity** | **0–0.50**, step **0.01**. Default **0.20**, shown with two decimals. |\r
| **Blur** | **0–200** px. Default **34**. |\r
| **Position X** / **Position Y** | **0–100%**. Defaults **22** and **30**. |\r
| **Scale** | **100–200%**. Default **100**. |\r
\r
Combined, the sliders keep the background readable. There is no noise control.\r
\r
---\r
\r
## Saved files\r
\r
![Предпросмотр файла](/screenshots/File_preview.jpg)\r
\r
The **Saved Files** section on the **General** page keeps local media copies for reuse.\r
\r
They are used in several places:\r
\r
* picking a background file in **Customize**;\r
* **File** fields in **Form-data** at a **Network** breakpoint;\r
* anywhere else the inspector needs to re-select a file you already saved.\r
\r
**Extension** vs **standalone** storage rules match the table above: same idea, different backing store and total capacity.\r
\r
### File list\r
\r
The section text is **Files saved from breakpoint form-data editing for quick reuse.**\r
\r
Columns are **Name** and **Size**. The row menu is **Edit** and **Delete**. **Edit** replaces that file. Clicking a row opens **File Preview** (name, size, type, and a preview for an image, audio, video, text, or PDF). An Office file shows its type, **Open**, and **Download**. **Add new file** sits under the rows and accepts several files. A file with the same **name** and **size** is skipped, with no message.\r
\r
In the **extension** the table is **Saved Files** only. In **standalone** it lists background wallpapers first, then the breakpoint files. The usage bar above the table is standalone only.\r
\r
**Auto-save new files selected via Browse** is off by default.\r
\r
When the option is on, a file is written to **Saved Files** when:\r
\r
* it was chosen via **Browse**;\r
* there is not already an entry with the same **name + size** pair.\r
\r
This applies, for example, when editing **Form-data** at a **Network** breakpoint.\r
\r
### Use in Form-data\r
\r
When you pick a file from the list in the **Form-data** editor, the draft stores a service reference of the form **\`__fileId:\`…**.\r
\r
When changes are applied, the injected script uses that id to attach the real file bytes to the request.\r
\r
Details: [Traffic interception](/network/traffic).\r
\r
---\r
\r
## See also\r
\r
* [Display modes](/options/display_mode)\r
* [JSON Mode](/options/json_mode) — how JSON is shown and edited.\r
* [Settings management](/options/settings_management)\r
`,I=`---\r
title: Display modes\r
---\r
\r
# Display modes\r
\r
**Options → General** starts with **Language**. The default is **English**; **Русский** switches the inspector navigation, the Options sidebar, and this General page. **Display Mode** then chooses **where** the Vue Inspector UI lives relative to the page: **Overlay** on the page or **DevTools tab** inside the browser’s developer tools. The default is **Overlay**.\r
\r
The rest of **Options → General**, in order: [Customize](/options/customize), [Search Parameters and Auto Refresh](/options/update_settings), [Auto Run](/options/auto_run) (extension only), saved files on the Customize page, [Settings management](/options/settings_management). JSON uses one editor ([JSON Mode](/options/json_mode)). **About** is the next Options section: [About](/options/about).\r
\r
> **DevTools mode requires the installed extension** (Chrome / Edge). **Standalone** disables the radios and shows **Display Mode is only available for the browser extension version.** The inspector only runs as an overlay.\r
\r
Choosing **DevTools tab** while the panel is the overlay shows **Reload the page to apply changes.** and **Open DevTools (F12) to access the panel.** Choosing **Overlay** while the panel is already a DevTools tab shows **Reload the page to apply changes.**\r
\r
---\r
\r
## Overlay — dock, pill, and size\r
\r
![Окно приложения](/screenshots/Window.jpg)\r
\r
**Overlay** embeds the panel above the site in its own “window” in the tab.\r
\r
The **pill** (compact handle with drag affordance and chevron) is the main control:\r
\r
* **Chevron** expands/collapses inspector chrome.\r
* **Drag handle** moves the block: near window edges it **snaps** top/bottom/left/right; centered becomes a **floating** framed window.\r
\r
**Default** first open: docked to the **bottom** — full-width strip with the site visible above (resize height). Classic bottom dock.\r
\r
**Resizing:**\r
\r
* Docked: grab the **outer** edge (for bottom dock, the **top** border) to change height (bottom/top dock) or width (left/right).\r
* Floating: corners and edges resize freely.\r
\r
Position, dock side, and floating geometry **persist** between visits (within browser/extension limits).\r
\r
Whether the pill shows on a site can also depend on **Auto Run** lists — see [Auto run](/options/auto_run).\r
\r
---\r
\r
## DevTools tab\r
\r
![DevTools](/screenshots/Devtools.jpg)\r
\r
> **Extension only.** The inspector opens as a **separate tab** inside native **DevTools** (F12 / Inspect), not as a floating overlay.\r
\r
Useful if you keep tools next to Console/Network or prefer not to cover the page. Pill dragging applies to **Overlay** only; DevTools layout follows the browser panel.\r
\r
After switching to **DevTools tab**, **reload** and open DevTools — you should see **Vue Inspector** among panel tabs.\r
\r
**Reload (F5):** the inspector tab reconnects to **this** tab’s page context. No extra enable step.\r
\r
**Versus Overlay:** while overlay is **collapsed**, some page-side flows may not get a full channel to the expanded panel — **Breakpoint** / **Mock** may need you to **expand** first. In **DevTools** mode the inspector is already an **active DevTools surface**, so **Network** interception works **immediately** after reload.\r
\r
**Network after F5:** the request list **clears and refills** as the page reloads, but **Network** features (intercept, breakpoints, mocks) are **ready from the start** — no extra click to “wake” networking.\r
\r
---\r
\r
## See also\r
\r
* [Auto run](/options/auto_run) — when the overlay pill auto-shows\r
* [Customize](/options/customize) — theme and panel background\r
* [Browser extension](/extension)\r
`,O=`---\r
title: JSON Mode\r
---\r
\r
# JSON Mode\r
\r
JSON across the inspector — request and response bodies in **Network**, payloads in **Mock response**, **Pinia** snapshots, and **Props** data when the content is JSON — opens in **vanilla-jsoneditor**.\r
\r
There is no Classic / Advanced switch. Older settings saved as **Classic** are read as this editor.\r
\r
- **Two representations of the same JSON**: **Text** (code) and **Tree** (structured). Switch them from the editor toolbar; the last choice is remembered (\`json.mode\`).\r
- **Text mode**: formatting helpers (**Format** / **Compact** where editing is allowed), **Undo / Redo**, **Search**, and copy.\r
- **Tree mode**: expand and collapse, breadcrumb navigation, context menus on nodes, and sorting.\r
\r
Non-JSON bodies (XML, plain text, and so on) stay in a single text view with Prism highlighting where that applies.\r
\r
---\r
\r
## See also\r
\r
- [Customize](/options/customize) — other **General** options (theme, background, saved files).\r
- [Display modes](/options/display_mode) — how the inspector panel is shown on the page.\r
`,P=`---\r
title: Settings management\r
---\r
\r
# Save, import, and export\r
\r
**Options → General** ends with **Import**, **Export**, and **Reset**. They work in **extension** and **standalone**, but **storage backends** and **export payload shape** differ.\r
\r
Everyday edits **autosave** (debounced) — there is no separate Save button for normal fields.\r
\r
A short comparison of where bytes go: [Installation → Where settings are stored](/install#storage).\r
\r
---\r
\r
## Normal persistence paths\r
\r
### Extension (Chrome / Edge)\r
\r
On autosave / import the background worker:\r
\r
1. Writes the **settings object** (options, tables, Network/Props rules, …) to **IndexedDB** for the extension — primary durable store.\r
2. **Mirrors** the structure to **\`chrome.storage.local\`** under a key like **\`vue-inspector-settings\`** for compatibility and quick access.\r
\r
Binary Customize files are **not** inlined in JSON — the object stores **ids/metadata** while blobs sit in **\`vue-inspector-media\`** IndexedDB. Keeps the settings blob small/fast to load.\r
\r
### Standalone\r
\r
Settings go through the local storage adapter into a **central KV** store (e.g. **\`inspector-settings\`** in IndexedDB via the **storage iframe**). **Not** \`chrome.storage\` — there is no installed extension.\r
\r
Decorative media uses the same storage perimeter with a **total size budget** (see [Customize](/options/customize)).\r
\r
**sessionStorage** may cache for first paint after reload — not a substitute for durable storage.\r
\r
---\r
\r
## Export\r
\r
**Export** downloads a JSON file named like \`vue-inspector-settings-YYYY-MM-DD.json\` (\`application/json\`, pretty-printed) of in-memory settings. The same file includes **Options → AI** under \`ai\`: the selected provider, models, personalization, agent access, and data masking. API keys are left out. Today's request counts and model quota marks stay in this browser. See [Options → AI](/ai/settings).\r
\r
* **Standalone:** for \`savedFiles\` rows backed by blobs, export may inline **data URIs** so the backup is **portable** across browsers/machines.\r
* **Extension:** data URI payloads for heavy files are usually **stripped** — you get structure/options; re-copy media locally or re-import a **rich** standalone export if you need bytes.\r
\r
Use Export for **backups**, **migration** (especially standalone), and **versioning** presets as JSON.\r
\r
---\r
\r
## Import\r
\r
**Import** picks a file. The picker accepts \`*.json\`. The payload must be the same JSON as export. Older exports named \`*.txt\` still import: the file was already that JSON, only the extension changed.\r
\r
When the file contains \`ai\`, those **Options → AI** choices replace the local ones. API keys in the file are ignored; keys already saved in this browser stay. A file with no \`ai\` object leaves **Options → AI** unchanged.\r
\r
1. Parse and **merge with defaults**: unknown keys drop; legacy shapes **migrate** when possible.\r
2. Result loads into the same options model, then **writes once** to durable storage (extension or standalone).\r
3. UI refreshes dependent lists (breakpoints, mocks, …).\r
\r
Blobs are **not duplicated** on write — JSON mostly carries ids; importing a **standalone** export with embedded data URIs hydrates attachments; importing a **trimmed** extension export moves options/lists — you may **re-pick** backgrounds in Customize afterward.\r
\r
Bad format **aborts** with an error in the form.\r
\r
Import **overwrites** current keys present in the file. **Export** first if you need rollback.\r
\r
---\r
\r
## Reset\r
\r
**Reset** restores factory defaults and clears related **media** stores. Extension path also clears IndexedDB settings keys and \`chrome.storage.local\` inspector keys. Standalone writes the reset through the same adapter as normal saves.\r
\r
**Irreversible** without a prior export.\r
\r
Partial Auto Run reset (without full wipe) exists via the extension **popup** — see [Auto run](/options/auto_run). **Reset** here clears the **entire** inspector profile. [Options → AI](/ai/settings), including the keys and today's request counts, stays.\r
\r
---\r
\r
## See also\r
\r
* [Installation — storage](/install#storage)\r
* [Customize](/options/customize)\r
* [Auto run](/options/auto_run)\r
`,C=`---\r
title: Update settings\r
---\r
\r
# Update settings\r
\r
Below **Customize** in **Options → General** you will find **Search Parameters** and **Auto Refresh**. They persist with the rest of the profile (see [Settings management](/options/settings_management)).\r
\r
---\r
\r
## Search Parameters\r
\r
Global rules for **text search** on **Props**, **Network**, **Pinia Stores**, and **Logs**. Defaults are **300** ms and **2** characters.\r
\r
### Search Debounce (ms)\r
\r
**Delay after typing stops** before the query applies. The field is marked **100–1000**. The default is **300**.\r
\r
### Minimum Search Length\r
\r
**Minimum characters** before a new filter runs. The field is marked **1–10**. The default is **2**.\r
\r
A shorter non-empty query does not start a new search. The previous result stays until the field is cleared or the query reaches the minimum. An empty field shows the full list. **Network** and **Logs** count the text inside double quotes. **Props** and **Pinia Stores** count the whole field, including the quote characters.\r
\r
---\r
\r
## Auto Refresh\r
\r
**Enable auto refresh** is off by default. **Refresh Interval** appears only while it is on. The default interval is **5 seconds**. The choices are **1 second**, **2 seconds**, **5 seconds**, **10 seconds**, and **30 seconds**.\r
\r
**Pinia Stores** reloads the store list on that interval while that tab is open and the panel is visible. A tick is skipped while a load is already running. Hiding the panel stops the timer; showing it starts the timer again if the checkbox is still on.\r
\r
**Props** reloads the component tree on that interval while the panel is visible, and stops while it is hidden. If **10** tree updates arrive within **5 seconds**, further updates are dropped for **10 seconds**. The console says \`Props update flood detected, entering cooldown\`. There is no switch for that. Changing the checkbox or the interval also starts a second **Props** timer that keeps running until you leave the **Props** tab, including while the panel is hidden.\r
\r
**Network** is not on this timer.\r
\r
---\r
\r
## See also\r
\r
* [Settings management](/options/settings_management)\r
* [Display modes](/options/display_mode)\r
`,R=`---\r
title: Blacklist\r
---\r
\r
# Component blacklist (Props)\r
\r
The **Props** **blacklist** is a set of **Vue component names** excluded from the inspector tree and table. Filtering runs **before** props collection, so hidden components are skipped during traversal.\r
\r
Props overview: [Overview](/props/general).\r
\r
Do not confuse this with the **site blacklist** for overlay **auto run** (**General / Auto Run**): here only **component names** are filtered.\r
\r
---\r
\r
## Add and remove\r
\r
* **Ignore by name** in the row menu adds the current component name to **Blocked**. An empty name is ignored. A name already in **Blocked** or **Allowed** is not added again.\r
* **Options → Props → Component Blacklist** — the list and its details card are below.\r
\r
---\r
\r
## Blocked and Allowed\r
\r
Rules have two states:\r
\r
* **Blocked** — a matching name is hidden.\r
* **Allowed** — an exception. A name that matches any **Allowed** rule stays in the list even when a **Blocked** rule also matches.\r
\r
**Allowed** rules do nothing when there is no **Blocked** rule. Deleting a row removes the rule entirely.\r
\r
### Component Blacklist in Options\r
\r
The block sits after **Inspect Mode**. The add field placeholder is **Component name (supports wildcards: *Comp*)**. **Add** or **Enter** trims the text and appends it to **Blocked**. An empty value shows **Name cannot be empty**. The same stored string already in **Blocked** or **Allowed** shows **This name is already in the blacklist**. That check is case-sensitive, so \`Foo\` and \`foo\` are two rules; name matching itself ignores case.\r
\r
| Column | What it shows |\r
| ------ | ------------- |\r
| **Component Name** | The stored pattern. |\r
| **Status** | **Blocked** or **Allowed**. **Allowed** rows are dimmed. |\r
\r
**Blocked** rows come first, then **Allowed**, each in the order they were added. The row menu (right click or **⋮**) is **Allow** or **Block**, and **Delete**. The empty table says *No components in blacklist*.\r
\r
A click opens **Blacklist Details**: **Component Name** and **Status** (**Blocked** or **Allowed**). There is no **Edit**. **Back** or **Escape** closes the card. With nothing selected the panel says *Select an item to see details*. If the rule was removed while the card is open, it says *Item no longer exists*. Below **1000** px the card covers the settings list until you go back.\r
\r
The card does not select that component on the Props tab.\r
\r
---\r
\r
## Name matching\r
\r
Comparison uses the **displayed component name**.\r
\r
* Without **\`*\`** or **\`%\`** — **case-insensitive exact** match.\r
* **\`*\`** and **\`%\`** act as wildcards for name fragments.\r
\r
Examples:\r
\r
* \`MyButton\` — only **MyButton**;\r
* \`Base*\` — names starting with **Base**;\r
* \`*Modal*\` — names containing **Modal**.\r
\r
Nameless components may show as **Anonymous** when that is what the tree uses.\r
\r
---\r
\r
## Intersections\r
\r
Any **Allowed** match wins: the name stays visible. Otherwise any **Blocked** match hides it.\r
\r
A broad **Blocked** pattern plus a narrower **Allowed** pattern keeps the exception visible. Toggling the broad rule to **Allowed** turns that pattern into an exception for every name it matches.\r
\r
---\r
\r
## When it applies\r
\r
Rules run on every tree rebuild:\r
\r
* manual **Refresh**;\r
* automatic refresh;\r
* reopening the tab.\r
\r
When the Props table already has rows, an **Options** edit refreshes it. An empty list picks up the rules on the next rebuild.\r
\r
While a **Blocked** rule hides a name, that component is not selectable in the table or card.\r
\r
---\r
\r
## Tips\r
\r
* Start from **exact names** via the row context menu.\r
* **Wide patterns** help repeated noise components but need care.\r
* **Blacklist affects inspector display only** — it does not change your Vue app.\r
\r
---\r
\r
## See also\r
\r
* [Props overview](/props/general)\r
* [Inspect](/props/inspect)\r
* [Customize](/options/customize)\r
`,N=`---\r
title: Favorites\r
---\r
\r
# Favorites (Props)\r
\r
**Favorites** under **Props** are persisted **components** you can return to across sessions. Starred rows float **to the top**, show a **star** beside the name, and a header badge counts favorites visible on the current screen.\r
\r
Props overview: [Overview](/props/general).\r
\r
**Pinia favorites** are separate (**Stores** tab and **Options → Pinia Store**); this page covers **Vue components** only.\r
\r
---\r
\r
## Add and remove\r
\r
* **In the component card** — header **star** toggles favorite for that component.\r
* **Row context menu** on **Props** — add/remove favorite.\r
* **Props table** — click the **star** area on a row to toggle even if the icon is not always visible.\r
* **Options → Props → Favorite Components** — the list and its details card are below. There is no **Add**; entries come from the Props tab.\r
\r
After changes the Props table **re-sorts** so favorites rise (unless search filters conflict).\r
\r
### Favorite Components in Options\r
\r
The block is last on **Options → Props**. There is no **Add**. Rows stay in the saved order.\r
\r
| Column | What it shows |\r
| ------ | ------------- |\r
| **Component** | The name, and under it the tag plus \`.\` and the stored class string. Spaces in the class string stay spaces. |\r
| **Added** | The locale date only. |\r
\r
The row menu is only **Delete**. **Delete** removes every saved entry with that id. The empty table says *No favorite components*.\r
\r
A click opens **Favorite Details**: **Component Name**, **Element** (tag plus \`.\` and the class string), and **Added** as the locale date and time. There is no **Edit**. **Back** or **Escape** closes the card. With nothing selected the panel says *Select an item to see details*. If the entry was removed while the card is open, it says *Item no longer exists*. Below **1000** px the card covers the settings list until you go back.\r
\r
The card does not select that component on the Props tab.\r
\r
---\r
\r
## What is stored\r
\r
Each entry keeps, among other fields:\r
\r
* **component name**;\r
* **identity** for matching in the tree (including root DOM signature: tag and classes);\r
* optional **nodeId** for the current session;\r
* **time added** (shown in Options).\r
\r
That lets favorites survive **reloads**: on rebuild the inspector matches saved signatures.\r
\r
---\r
\r
## Matching\r
\r
Matching uses **stable identifiers** when refreshing the tree.\r
\r
* If a numeric **session uid** is stored, it only matches **within the current tree lifecycle** (full rebuild changes uids).\r
* Entries with **name + root element signature** match on **stable cues**, not internal tree path.\r
\r
Legacy entries with only **session uid** may also use **metadata** (name, tag, class) to reconnect after reload.\r
\r
If several candidates look alike, the wrong instance may star — remove and re-add from the correct row.\r
\r
---\r
\r
## Header badge\r
\r
The badge is always shown. It reads \`0\` when nothing is saved, otherwise visible favorites / saved total. It is yellow when at least one visible row is a favorite.\r
\r
Clicking the badge opens **Options → Props → Favorite Components**.\r
\r
---\r
\r
## Tips\r
\r
* Use favorites for **anchor components**: headers, widgets you check often, problem areas.\r
* After **DOM structure changes**, verify stars still point to the right instance.\r
* Favorites **do not** affect runtime behavior and are unrelated to the component **blacklist**.\r
\r
---\r
\r
## See also\r
\r
* [Props overview](/props/general)\r
* [Blacklist](/props/blacklist)\r
* [Customize](/options/customize)\r
* [Store overview](/store/general) — separate Pinia favorites\r
`,q=`---\r
title: Components and props\r
---\r
\r
# Components and props\r
\r
The **Props** tab shows the **Vue instance tree** on the page: component names, link to the root DOM node, and props summaries. Full values load when you select a row; you can edit and write back where supported.\r
\r
**Inspect mode**, **favorites**, and the **component blacklist** are covered on separate pages: [Inspect](/props/inspect), [Favorites](/props/favorite), [Blacklist](/props/blacklist).\r
\r
## Top toolbar\r
\r
![Props, область заголовка](/screenshots/Props_header.jpg)\r
\r
### Component search\r
\r
The search field supports several modes. Active criteria come from **Search by** next to the input. The same checkboxes are the first block on **Options → Props**, under **Search Settings**: **Search by component name**, **Search by root element**, **Search by key**, **Search by value**. Defaults: name and root element on; key and value off. A change applies to the open Props list immediately.\r
\r
On **Options → Props** the blocks follow in this order: **Search Settings**, **Inspect Mode**, **Component Blacklist**, **Favorite Components**, **Prop rules**. Inspect, the blacklist, and favorites are described on their own pages; prop rules are in [Save as](#save-as).\r
\r
| Mode      | What the list uses                                                                                          |\r
| --------- | ----------------------------------------------------------------------------------------------------------- |\r
| **Name**  | component \`name\`                                                                                            |\r
| **Root**  | the **Root Element** string (\`tag\`, \`#id\`, \`.classes\`, \`[data-testid]\`, or \`Logic only\`)                   |\r
| **Key**   | prop names, including nested keys                                                                           |\r
| **Value** | prop values, including nested values                                                                        |\r
\r
A non-empty query keeps a row when any enabled mode matches (**Name**, **Root**, **Key**, **Value**). With all of them off, the query matches nothing.\r
\r
Minimum length applies to every mode. Default **2** characters and **300 ms** debounce, from **Options → General → Search Parameters** ([Update settings](/options/update_settings)). A shorter non-empty query does not start a new search; the previous result stays until the field is cleared or the query reaches the minimum.\r
\r
**Key** and **Value** ask the page for matches. If that request fails, they match nothing; **Name** and **Root** still filter in the panel. The local fallback walks \`props\` to depth 20.\r
\r
**Partial vs exact.** If the query is **not** wrapped in quotes, enabled text modes use **substring** matching (case-insensitive). **Exact** whole-string match applies when the **entire** search text is wrapped in **double quotes** \`"..."\`.\r
\r
**Inspect** next to search picks a node on the page to filter the list; see [Inspect](/props/inspect).\r
\r
### Status chips\r
\r
Right side of **Props**:\r
\r
| Item                       | Purpose                                                                                          |\r
| -------------------------- | ------------------------------------------------------------------------------------------------ |\r
| **Filtered** (amber badge) | A page-element filter (**Inspect**) is active. Click clears the filter and restores the full list. |\r
| **N** or **N/M**           | **N** is visible rows. **/M** appears only when the search field is not empty and the counts differ. The Inspect filter alone does not add **/M**. |\r
| **Favorites** ★            | Visible favorites / saved total, or \`0\` when none are saved. Yellow when at least one visible row is a favorite. Click opens **Options → Props → Favorite Components**. |\r
| **Prop rules** (pin)       | Rules applied to components on this page / enabled rules, or \`0\` when there are none. Purple when at least one rule is applied. Click opens **Options → Props → Prop rules**. |\r
| **Update**                 | **Refresh** button and last snapshot time (\`lastUpdated\`).                                       |\r
\r
## Work area\r
\r
![Props, полноэкранный режим](/screenshots/Props_full_screen.jpg)\r
\r
### Component list\r
\r
Left: the component table. **Name** is always shown. The column menu toggles **Root Element**, **Received**, and **Declared**; all three default to on.\r
\r
* **Name** — component name;\r
* **Root Element** — \`tag#id.class[data-testid]\`, or \`Logic only\` when there is no DOM node. The cell truncates at 25 characters; the full string is the tooltip. \`Logic only\` uses the warning badge;\r
* **Received** — count of props actually passed;\r
* **Declared** — count of props declared on the component.\r
\r
A row with no received props is dimmed, shows **—** in **Received** and **Declared**, and does not open the card. The empty list says **No components found**.\r
\r
Hover highlights the page node only when the row has a DOM element. A \`Logic only\` row clears the highlight. Favorite rows do not take the hover background. Search clears the highlight.\r
\r
A row with a purple bar on the left gets values from a [prop rule](#save-as); the tooltip lists the props the rule holds. The selected row of such a component has a purple background, like a mocked request on **Network**.\r
\r
The row menu is **Ask AI**, **Add favorite** / **Remove favorite**, **Delete rule** (only on rows with a [prop rule](#save-as)), and **Ignore by name**. The star on the row does the same favorite toggle. See [Favorites](/props/favorite) and [Blacklist](/props/blacklist).\r
\r
**Ask AI** in the row menu attaches the current props of the component to a question for the assistant. The **AI** tab opens with a chip above the input, for example *OrderCard props*: **×** removes it from the question. Type a question, or send the chip without one. Values are masked by the AI settings and cut; with **Values of store state, props, emits and actions** off, the assistant gets only names and types. The item is disabled for a component without props.\r
\r
## Component details\r
\r
Selecting a component row that has received props opens the detail panel. With nothing selected the panel says **Select a component to see details**.\r
\r
### Summary header\r
\r
The top of the panel shows:\r
\r
* component name;\r
* short **root DOM** info (tag and classes), truncated at 40 characters with a tooltip for the rest. When the row has no root element the badge shows \`div\` (the table shows \`Logic only\`);\r
* size of the serialized **Received** payload, hidden when that payload is empty;\r
* a purple pin badge with the number of props held by prop rules, shown only when a rule applies; click opens **Options → Props → Prop rules**;\r
* an **Updated:** line with the node timestamp, or **—** when the node has none.\r
\r
### Component data\r
\r
Two tabs below:\r
\r
| Tab          | Purpose                                                                       |\r
| ------------ | ----------------------------------------------------------------------------- |\r
| **Received** | props actually passed; view and edit supported                                |\r
| **Declared** | declared prop definitions (**rawProps**); view only                          |\r
\r
Both tabs are always available.\r
\r
The active tab is shown as **JSON**—text or tree—according to inspector settings.\r
\r
The editor supports **copying** the contents.\r
\r
### Navigation\r
\r
* **← Back** closes the card, including during edit;\r
* **Esc** in edit mode discards the draft and stays on the card;\r
* **Esc** outside edit mode closes the card.\r
\r
### Controls\r
\r
| Control     | Purpose                                                                                                                                 |\r
| ----------- | --------------------------------------------------------------------------------------------------------------------------------------- |\r
| **Star**    | add or remove from favorites; always available                                                                                         |\r
| **Refresh** | re-fetch the selected component from the page; temporarily disabled while a refresh runs; **hidden** in **Edit** mode                  |\r
| **Edit**    | enter edit mode; **only on the Received** tab                                                                                          |\r
\r
Button order in the header (view mode): **Star → Refresh → Edit**. **Save as** sits under them.\r
\r
### Edit mode\r
\r
**Edit** applies **only** to the **Received** tab.\r
\r
When editing, **Refresh** and **Edit** become **Cancel** and **Save**. **Star** stays available, and so does **Save as** under the buttons; see [Save as](#save-as).\r
\r
| Before editing | In edit mode                                                                 |\r
| -------------- | ----------------------------------------------------------------------------- |\r
| **Refresh**    | **Cancel** — revert the draft to the last loaded props and leave edit mode    |\r
| **Edit**       | **Save** — write changes to the app                                           |\r
\r
* **Save** is disabled if JSON fails validation;\r
* changes apply only after **Save**;\r
* there is no toast. If the page rejects the write, edit mode still closes and the editor keeps the draft until the next props update; the failure is in the console. If save throws, edit mode stays open.\r
\r
**Removing keys.** A prop deleted from the JSON gets the value Vue uses when the parent does not pass that prop:\r
\r
* the prop's **default** (a factory function is called);\r
* \`false\` for **Boolean** props without a default;\r
* otherwise \`undefined\`.\r
\r
Keys deleted inside an object prop are removed from the object. This lets you check how a component behaves when optional data is missing. After saving, the card shows the edited JSON; use **Refresh** to see the resolved values.\r
\r
### Save as\r
\r
**Save as**, under the header buttons, chooses what **Save** keeps. A component has one value here. The list is disabled in view mode and can be changed only while editing. **Cancel** restores the value the component had when editing started.\r
\r
* **Once** — the basic mode. **Save** changes the live component only. A reload, or the component being created again, brings back the values from the parent. If the component already has a rule, **Save** deletes it.\r
* **Part** — the rule stores only the props changed in this edit. Saving again adds or updates those props in the same rule. A key deleted from the JSON is removed from the rule. With no change and no existing Part rule, nothing is stored.\r
* **Full** — the rule stores every current prop. Saving again replaces the rule with the props in the JSON at that moment.\r
\r
A rule applies to components with this name at the same route of parent components (for example \`App › Layout › OrderCard\`). Identical siblings at that route, such as list items, all match. The component gets the rule values as soon as it is created, before its \`setup()\` and first render. Code that copies a prop into local state on creation sees the rule value too.\r
\r
What the rule stores:\r
\r
* the site (\`host\`) where it was saved. Other sites ignore it;\r
* values as JSON, so functions and other non-JSON values cannot be kept.\r
\r
While a rule applies, the parent's value is set aside: updates from the parent do not overwrite the rule value. Disabling or deleting the rule gives the component the parent's current value back at once, without a reload. Opening a component that has a rule shows **Part** or **Full** in **Save as**. A rule saved before these two values existed is shown as **Full**. **Delete rule** in the row menu deletes the rule at once.\r
\r
**Options → Props → Prop rules** lists the rules after **Favorite Components**: component, site and route, the props it holds, and status. The row menu has **Edit**, **Enable** / **Disable**, **Delete**; **Edit** opens the values as JSON in the details panel. **Apply rules** next to the title turns all rules off without deleting them.\r
\r
In the extension, rules are applied on page load even when the inspector panel is closed; the bookmarklet build applies them once it starts. A page that loads Vue 3 through a bundler (Vite, webpack) with Vue 3.3 or newer gets the values on the first render. Other builds and Vue 2 get them once the inspector starts on the page; components created after that get them on creation.\r
\r
The **favorite** star in this panel and in the table is described on [Favorites](/props/favorite).\r
\r
Card data reflects the **last successful** update for the selected node—use **Refresh** in the detail header to re-query props from the page, or toolbar **Refresh** on **Props** for a full snapshot refresh.\r
\r
## Display limits\r
\r
### Reading limits\r
\r
**Props on demand:** opening a card reads and serializes values for the detail panel; heavy objects hit serializer limits (below).\r
\r
The light table sends metadata and counts without full serialization of every value on each update.\r
\r
### Storage\r
\r
There is no fixed “N rows like **Network**” cap for **Props**: size depends on component count and injected-side cache policy (snapshots are pruned where a node is not expanded and not needed).\r
\r
To avoid blocking the page main thread, prop serialization applies limits including:\r
\r
* time budget per serialization pass;\r
* max nesting depth and array/object size;\r
* long string truncation and a cap on nodes per response.\r
\r
Very large or cyclic structures may appear incomplete or marked as truncated—expected safeguard behavior.\r
\r
## How it works\r
\r
### When collection starts\r
\r
The Props module attaches **after Vue is detected** on the page (unlike **Network**, which starts with the general inspector script). Until Vue initializes or the inspector is injected in the tab, the component list stays empty.\r
\r
After the first successful load you can refresh manually (**Refresh**) or on a schedule (**auto refresh** in **Options**).\r
\r
### What is monitored\r
\r
1. **Structure** — walking Vue instances yields a flat list with metadata (name, label when present, element binding, **received** and **declared** counts without full values every frame).\r
2. **Props on selection** — full values load when you open a card (lazy).\r
\r
The same channel refreshes after **Toolbar** **Refresh**, respecting the active **blacklist** (name filtering during collection—see [Blacklist](/props/blacklist)).\r
\r
### Messaging model\r
\r
The panel does not read Vue memory directly: it sends a message to the page; injected code walks instances and returns serialized data.\r
\r
Simplified flow:\r
\r
\`\`\`js\r
// Illustration: UI requests the component list; the page scanner builds structure.\r
const response = await bridge.send({\r
  type: 'COLLECT_VUE_COMPONENTS',\r
  forceRefresh: true,\r
  blacklist: { active: ['SomeNoise'], inactive: [] },\r
})\r
// response.components — names, uid, prop counts, Root Element strings…\r
// Full prop payloads load separately when a card opens (lazy).\r
\`\`\`\r
\r
This separates the **light table** from **heavy prop reads** for the selected node only.\r
\r
## See also\r
\r
* [Inspect — pick a component on the page](/props/inspect)\r
* [Favorites](/props/favorite)\r
* [Blacklist](/props/blacklist)\r
* [Update settings & auto refresh](/options/update_settings) (**Options**)\r
`,E=`---\r
title: Inspect\r
---\r
\r
# Inspect mode (pick a component on the page)\r
\r
![Инспектор](/screenshots/Inspector.jpg)\r
\r
**Inspect** on the **Props** tab lets you pick UI on the **page** and, after click, narrow the component list to the subtree tied to that node — similar to picking an element in browser DevTools, but the result is **filtering the Props table**, not opening the DOM tree.\r
\r
Overview: [Props overview](/props/general).\r
\r
---\r
\r
## Start and stop\r
\r
The **Inspect** control (pointer icon) lives on the **Props** toolbar and enables picking an element to filter components. Tooltip: **Select element on page to filter Props**. The button is disabled while the list is loading. On a narrow toolbar it moves to the row under the search field.\r
\r
Before activation the component list **refreshes** so the tree matches the page.\r
\r
By default **Inspect** temporarily **hides** the inspector overlay so it does not cover the page. The checkbox is **Options → Props → Inspect Mode → Hide overlay while inspecting**, and it is on by default. The value is read when Inspect starts. Changing it during a pick does not move the overlay until the next start.\r
\r
Clicking **Inspect** again stops picking **without** clearing an applied filter.\r
\r
**Escape** cancels picking without selecting.\r
\r
Switching tabs or closing the panel resets pick mode.\r
\r
---\r
\r
## On-page behavior\r
\r
With Inspect, pointer moves and clicks are handled **above** normal page behavior, including elements that usually ignore clicks.\r
\r
Selection binds to the nearest DOM node linked to a **Vue instance**.\r
\r
While moving the pointer, the element under it **highlights** and a **tooltip** may show:\r
\r
* component name;\r
* root element summary (tag, class fragment or \`id\`);\r
* props count;\r
* nested component count.\r
\r
Tooltip light/dark follows inspector theme.\r
\r
**Vue Inspector** UI (overlay, chevron, Inspect helpers) is excluded from picking.\r
\r
If **Hide overlay while inspecting** is on, the UI returns after pick or cancel.\r
\r
---\r
\r
## After you pick\r
\r
When a page element is chosen:\r
\r
* Inspect mode ends;\r
* the **Props** table keeps components whose root element is the picked element or inside it. If that element is gone, the list is empty;\r
* a **Filtered** chip shows the list is scoped. Its tooltip is **Clear element filter, show full list**. The chip does not add **/M** to the search counter.\r
\r
Click **Filtered** to clear the filter and reload the full list.\r
\r
Starting Inspect again with a filter active lets you pick another root and replace the scope.\r
\r
---\r
\r
## Limits and notes\r
\r
* If there is no Vue-related node under the cursor, selection may not filter.\r
* Deep DOM may resolve to the nearest component, not the visually expected level.\r
* Inspect only affects the component list; **favorites**, **blacklist**, and **search** still apply on top.\r
\r
More: [Favorites](/props/favorite), [Blacklist](/props/blacklist).\r
\r
---\r
\r
## See also\r
\r
* [Props overview](/props/general)\r
* [Favorites](/props/favorite)\r
* [Blacklist](/props/blacklist)\r
`,W=`---\r
title: Release history\r
---\r
\r
# Release history\r
\r
## [2.0.0] - 2026-01-23\r
\r
### Core\r
\r
* Corporate-friendly build that does not require installation.\r
* Version tracking and notifications for new updates.\r
* Project moved to an **iframe** entry; **popup** is no longer the primary entry point.\r
\r
---\r
\r
### Performance\r
\r
* Fixed a memory spike on static sites, including Docusaurus and Hugo.\r
\r
---\r
\r
### UI / UX\r
\r
* Refreshed styles and overall visual design.\r
\r
## [2.1.0] - 2026-02-02\r
\r
### Core\r
\r
* New **Network** management tab.\r
* Redesign for **iframe** layout instead of **popup** — more useful space on screen.\r
* JSON layout tweaks — editor uses full app height.\r
* Fixed tabs sticking when opening early — **Props** and **Pinia** no longer require a full page reload to appear.\r
\r
---\r
\r
### Props\r
\r
* Fixed favorites not resolving after reload or repeated flows.\r
* Optimized Props for long sessions without excessive CPU; internal refactor.\r
* Props tab overhaul — better behavior with large trees and hover search.\r
* Removed **Props only** mode.\r
\r
---\r
\r
### Network\r
\r
* Intercepts **fetch** and **XMLHttpRequest** except **OPTIONS** and extension-originated calls.\r
* Summary columns: status, method, name, duration, size.\r
* Detailed view: params, auth, headers, request, response — only CORS-exposed headers where applicable.\r
* Pause/resume capture; recording on by default on first open.\r
* **Breakpoint** — pause and edit outbound requests before send.\r
* **Mock Response** — intercept and return a synthetic response.\r
* Quick copy of URLs, tokens, and key fields.\r
* Clear all captured requests.\r
* Event-driven architecture without polling for lower CPU.\r
* Binary detection — textual preview suppressed with metadata only.\r
\r
## [2.2.0] - 2026-02-24\r
\r
### Core\r
\r
* **Display Mode** — move the app into a **DevTools** tab or disable pure overlay.\r
* **Options** reorganized into logical sections.\r
* **Props**, **Pinia Store**, and **Network** filters editable inline without jumping to Options.\r
* Fixed JSON text-mode click target area.\r
* Large JSON no longer truncates — heavy CSS disabled for performance.\r
* Update notifications revised:\r
\r
  * **Dismiss** → **Later**;\r
  * **Download** → **Preview** pointing to **Options → About**;\r
  * detail block with **Ignore** and **Download**.\r
\r
---\r
\r
### Props\r
\r
* Fixed missing Props hover highlight in **Standalone**.\r
\r
---\r
\r
### Network\r
\r
* **form-data** support for reading and traffic substitution.\r
* Saved files for reuse with **Breakpoint** / **form-data**.\r
* **Rewrite Breakpoint** / **Rewrite Mock** — overwrite existing rules instead of duplicating.\r
* Badges for active **Breakpoint** / **Mock** per request; click opens matching Options.\r
* Search by HTTP status code.\r
* **Breakpoint** rules consider HTTP method.\r
* Fixed inspector not opening when a **breakpoint** fired.\r
* Context menu entries: **Disable/Enable Breakpoint**, **Disable/Enable Mock**, **Delete Breakpoint/Mock** (shown when applicable).\r
\r
---\r
\r
### Options\r
\r
#### General\r
\r
* Core settings (**Display Mode**, **Search Parameters**, **Auto Refresh**, **JSON Editor Mode**) grouped together.\r
* **Settings Management** moved from the tab header.\r
\r
#### Network\r
\r
* **Search Settings** split into their own section and decoupled.\r
* **Breakpoints** / **Mocks** table layout fixes — rows no longer over-stretch.\r
* Toggle and edit existing rules.\r
\r
#### Props\r
\r
* Settings file controls moved into the section.\r
* **Component Blacklist** moved here from the general block.\r
* **Favorite Components** moved here from the general block.\r
\r
#### Pinia Store\r
\r
* Settings file controls moved into the section.\r
\r
#### About\r
\r
* **Release notes** and **Check for updates** (extension only).\r
* When an update exists:\r
\r
  * **Ignore** silences this version until a newer one ships;\r
  * **Download** fetches the app archive.\r
\r
## [2.3.0] - 2026-03-16\r
\r
### Network\r
\r
* **Postman** collection export from captured **Network** traffic.\r
* Single-panel mode: **Copy cURL** replaced with a header context menu — **Breakpoint**, **Mock**, **Copy cURL**.\r
* Right-click context menu on request detail header.\r
\r
---\r
\r
### Props\r
\r
* Favorites and blacklist behavior fixes.\r
* Blacklist applied during collection traversal (not only table filtering) — faster Props load.\r
* Quick actions menu for **Props**.\r
* Refresh open component in read mode.\r
* Shortcut jump to favorites from the favorites counter.\r
\r
---\r
\r
### Store\r
\r
* Pinia **favorites** with shortcut navigation.\r
* Quick actions menu for **Pinia Store**.\r
* Refresh open entry in read mode.\r
* **Options** supports manual favorite entries with **wildcards**.\r
\r
---\r
\r
### Options\r
\r
* User files now persist as local copies in app storage.\r
* **Standalone** uses dedicated local storage — settings survive relaunch and work across sites.\r
* Tree JSON editor temporarily disabled — text mode only.\r
\r
#### Customize\r
\r
**Options → General → Customize** adds theming:\r
\r
* **Dark / Light** color scheme;\r
* **Image** background (**File / Link**) with stills, **GIF**, **MP4**;\r
* **Browse** or pick from saved files;\r
* Add by URL;\r
* **Image Opacity**, **Blur**, **Noise Intensity / Opacity**, **Position (X / Y)**, **Scale** (**100–200%**).\r
\r
---\r
\r
### UI / UX\r
\r
* Responsive layout for smaller screens.\r
* Wide layout: split list + details.\r
* ~**1000px** width collapses to single-panel.\r
* **Esc** closes panels/dialogs.\r
* **Ctrl+F** search in **DevTools** tab mode.\r
* Loading skeletons for **Props** / **Pinia** tables instead of raw “Not found”.\r
* Column visibility toggles for **Props**, **Pinia**, **Network**.\r
* Chevron redesign for iframe open/close.\r
* Table context menus (right-click).\r
\r
---\r
\r
### Performance\r
\r
* Blacklist applied during Props tree pre-walk — faster data collection and tab load.\r
\r
---\r
\r
### Fixes\r
\r
* JSON edit hit area while scrolling.\r
* **Network** tab freezes after long sessions.\r
* **Ctrl+A** selects only the focused input.\r
* Reset/delete buttons respect **disabled** state.\r
* **Options** tables with many rows.\r
* JSON edit mode styling.\r
* Minor cosmetic fixes.\r
\r
## [2.4.0] - 2026-04-05\r
\r
### Network\r
\r
* When **Pause** is enabled, inspector interceptors are detached, so native DevTools display the **original initiator** instead of **injected.ts**.\r
* The **Network** table now uses virtualization for better performance and reduced UI freezes.\r
* The request details view now opens on the **Response** tab by default.\r
* When a **Breakpoint** is triggered, the paused method automatically opens on the **Request** tab.\r
* **Search by** lists on the **Network** tab and in **Options** now support searching by the **Name** column.\r
\r
---\r
\r
### Props\r
\r
* **Props** performance has been significantly improved, making **auto refresh** safe to use.\r
\r
* In the **Props** table, the **Props** column has been split into **Passed** and **Declared** (all columns can be hidden):\r
\r
  * **Passed** — number of props currently received;\r
  * **Declared** — number of props declared on the component.\r
\r
* In the right-side **Props details** panel, data is now split into two tabs:\r
\r
  * **Passed** — props currently received (opened by default);\r
  * **Declared** — all props declared by the component.\r
\r
* The **Props details** panel now includes a **Size** parameter.\r
\r
#### Inspect (Props Inspector)\r
\r
* Added page element selection mode similar to **Chrome DevTools Elements**.\r
* Allows selecting elements directly on the page for quick **Props** filtering.\r
* Highlights **Vue** components on hover.\r
* Displays quick element info: **Name**, **Root element**, **Received Props**, **Nested components**.\r
* After selection, **Props** displays only the selected element and its nested components.\r
* The filter can be quickly cleared via the **Filtered** badge.\r
\r
---\r
\r
### UI / UX\r
\r
#### Windowed mode\r
\r
* Added support for windowed mode with saved position for both launch modes.\r
* Updated the iframe open chevron with a drag indicator.\r
* Added support for docking the launcher to any of the four browser edges with automatic vertical stretching.\r
\r
#### Auto launch settings\r
\r
* Added **Whitelist** for automatic app launch and **Blacklist** for excluded sites where launch and launcher display are disabled.\r
* Added extension **popup** with quick actions:\r
\r
  * **Forced Launch** — launches the app ignoring whitelist, blacklist, and static-site restrictions;\r
  * **Reset Settings** — resets all extension settings.\r
\r
#### Other UI improvements\r
\r
* Fixed **JSON** styling for large data volumes.\r
* Added exact search when entering values in quotes; without quotes, search works in **like** mode.\r
* Minor visual interface improvements.\r
* Improved **Esc** behavior in **DevTools** mode: first closes nested tabs, and when nothing else remains, opens the **DevTools Console**.\r
\r
---\r
\r
### Performance\r
\r
* Improved **Props** and **Store** detection mechanism for significantly faster data retrieval.\r
* Increased limits for maximum readable **Props** count.\r
* Refactored internal project structure: removed unused modules, dead code, and duplicated logic.\r
\r
---\r
\r
### Documentation\r
\r
* Full project documentation has been added.\r
* Added a **Documentation** section to the landing page.\r
* Added quick documentation access via **Options → About**.\r
\r
---\r
\r
### Fixes\r
\r
* Blocked native right-click menu inside the application context menu.\r
• Fixed incorrect favorite detection in Props details when names matched.\r
* Improved search behavior in **DevTools mode**: fixed cases where search could stop working and added highlight reset when clearing the field or closing search.\r
* Fixed an issue when saving changes to **Getters** in **Pinia Store**.\r
* Fixed an issue with retrieving **Props** data in **Vue** during local development.\r
* Fixed **Network** issues during local development.\r
\r
## [2.5.0] - 2026-05-17\r
\r
### Network\r
\r
* Network header sections can be **collapsed** and **expanded**.\r
* The app **remembers the last details tab** you used; when you open another request, it opens on the **same tab** you had selected while viewing the previous request.\r
\r
**Global suspend for Breakpoint and Mock**\r
\r
On the **Network** toolbar (right side, next to log recording controls), two buttons were added: **suspend / resume all breakpoint rules** (pause-in-circle icon; active — **amber** accent) and **suspend / resume all mock responses** (shuffle icon; active — **purple** accent). Rules are **not** removed from **Options → Network**; when turned off, that interception type is **not** applied on the page. The same flags are controlled by **Enable breakpoint rules** and **Enable mock responses** next to the lists in **Options**; the toolbar and **Options** stay in sync. **bp** and **mock** badges use a **muted** style when global rule application is disabled.\r
\r
**Network capture: Advanced mode**\r
\r
**Network** settings include **Advanced mode**: the extension requests additional permissions and collects the **full** request and response header set (including headers not always visible in the regular DevTools **Network** tab because of page limitations). **Classic mode** still shows only headers available in the standard “classic” view without bypassing those limitations.\r
\r
**Standalone**\r
\r
Advanced capture and related features are **not available in Standalone**: only the classic flow runs there, without extended headers and without Advanced-only menus and settings.\r
\r
**What Advanced mode adds in Network**\r
\r
* **Extra headers** in the Request / Response areas on the selected request’s Headers tab.\r
* **Pinned headers** — pin names to the top of the list separately for **request** and **response**; edit pins in settings (Advanced only).\r
* **Header links** — per host and URL template, open an external resource with the header value substituted (e.g. traces, ID lookup, internal dashboards). Manage rules in **Network** settings and from the header row context menu (when Advanced).\r
* **Header links** and **Pinned headers** in **Options** are shown **only when Advanced mode is enabled** so Classic mode stays uncluttered.\r
\r
---\r
\r
### UI / UX\r
\r
**JSON Mode (**Options → General**)**\r
\r
**Options → General** now includes a **JSON Mode** switch with two options:\r
\r
* **Classic** — built-in text editor with Prism syntax highlighting (**JsonTextEditor**): a single text view with no tree, tuned for large payloads (reduced highlighting on very long JSON and a lightweight viewer for large non-JSON read-only bodies).\r
* **Advanced** — **vanilla-jsoneditor**: two views of the same JSON — **Text** (code) and **Tree** (structure); switch from the toolbar; the last selected mode (**Text** / **Tree**) is **saved** in settings (**json.mode**). Advanced provides **Format** / **Compact** (where editing is allowed), **Undo / Redo**, **search**, copy; in tree mode — expand/collapse, path navigation, context menus, and sort/edit flows built on the tree.\r
\r
The **Classic / Advanced** choice selects the JSON implementation across the UI (**Network** and **Mock** bodies, **Pinia** snapshots, JSON on **Props**, etc.). Non-JSON content still uses text view with highlighting where supported.\r
\r
## [2.6.0] - 2026-10-17\r
\r
### Logs\r
\r
A new **Logs** tab: one chronological journal of page events. Available in the extension and in **Bookmark** (Standalone) mode, always placed after **Pinia Store**.\r
\r
#### Event types\r
\r
* **Send request** / **Receive response** — \`fetch\` / \`XMLHttpRequest\` requests and responses with parameters, headers, body, status, duration and size.\r
* **WebSocket open** / **WebSocket sent** / **WebSocket received** / **WebSocket closed** — opening and closing connections, sent and received messages, headers, duration and the close reason.\r
* **Change props** — component prop changes with a **Before** / **After** comparison.\r
* **Emit** — component events, arguments, listener type and the parent chain.\r
* **Change store** — Pinia state changes with a **Before** / **After** comparison. An existing store keeps an initial snapshot; a new store keeps its full state at creation.\r
* **Store action** — arguments, result or error, status and duration of Pinia actions.\r
* **Navigation** — SPA navigation with **From** / **To**. The current page is saved when recording starts and after **Clear**.\r
* **JS error** — uncaught errors, unhandled promise rejections and page \`console.error\` calls. The message, source, location and stack are shown. Messages of Vue Inspector itself and of other browser extensions are not recorded.\r
\r
#### Table and details\r
\r
* Columns **Time**, **Type**, **Event**, with highlighting for errors and failed requests: **4xx** is a warning, **5xx** and errors are a critical status.\r
* Filter by event type and search by names, keys and values. Search modes are set in **Options → Logs → Search Settings**; a quoted query matches exactly.\r
* **Pause** stops recording, **Clear** empties the journal. Events are collected from the moment the inspector starts, even if the **Logs** tab is opened later.\r
* Details depend on the event type and include the relevant data: request parameters, headers, JSON, WebSocket messages, event arguments and state snapshots.\r
* Prop and Pinia changes include a **diff** of added, removed and changed paths.\r
* Actions menu: **Export event**, **Copy cURL**, jump to the paired request or response, **Ignore** to stop recording the selected group of events.\r
\r
#### Selection and export\r
\r
* Select events with checkboxes, **Shift + click** for a range, **Ctrl / Cmd + click** to toggle individual rows.\r
* **Export Logs (n)** exports the selected events. With nothing selected, every event that matches the current filters is exported.\r
* Requests and responses are always exported together.\r
* **Export Logs** and a single-event export create a self-contained HTML report, format version 1, that opens offline.\r
* Pinia changes in the report keep the data needed to view **Before** / **After**, even when earlier events were not exported.\r
\r
### HTML report\r
\r
A self-contained HTML report with a dark theme and no external resources.\r
\r
* Sections **Report**, **Network**, **WebSocket**, **Components**, **Pinia**, **Page** with event counters.\r
* **Overview** summary, and **Events**, **Errors** and **Failed requests** cards that open the matching events.\r
* Search by titles and inside data (**in data**).\r
* Keyboard navigation (**↑ / ↓**, **Esc**) and direct links to events.\r
* Details with the same tabs as **Logs**, and a jump between a request and its response.\r
* **Locate** opens the event list and brings the selected event into view.\r
* A **Support Vue Inspector** section with links to Boosty and a USDT donation over Tron (TRC-20).\r
\r
### Network\r
\r
* Select requests with checkboxes and export only the selected rows with **Export Collection (n)**.\r
* **bp** and **mock** counts open the list of active rules. **Pause** suspends a rule, **×** deletes it.\r
* On a narrow panel, saving a **Breakpoint** / **Mock** or leaving the form with the back button closes the request details. On a wide panel they stay open.\r
* After a request or response is edited at a **Breakpoint**, the data that was actually sent is shown.\r
* WebSocket connections are listed as separate **WS** rows, including ones already open when the inspector starts.\r
* **Headers** shows the handshake headers, **Messages** shows sent and received frames, newest first. JSON is formatted; direction and size are shown.\r
* The latest 200 messages of a connection are kept. WebSocket is not included in **Export Collection**; **Breakpoint** and **Mock** stay available for HTTP.\r
* **Logs** and the HTML report record WebSocket events separately: **open**, **sent**, **received**, **closed**.\r
* A recognized Centrifuge close, for example **3501**, shows the reason and **No automatic reconnect**. Sending \`{}\` on that connection shows a warning that the socket may close.\r
* Binary responses show a notice with the content type; in the HTML report it uses the same styling as the truncated-data warning.\r
\r
### Props / Pinia Store\r
\r
Saving removed keys in **Edit** mode is fixed.\r
\r
* **Pinia** — nested keys are deleted from the store; removing top-level keys is handled for both options stores and setup stores.\r
* **Props** — a removed prop gets the value Vue uses for a prop that is not passed: its **default**, \`false\` for **Boolean**, otherwise \`undefined\`. Nested keys of object props are deleted.\r
\r
### Options → Logs\r
\r
* **Search Settings** — default search modes.\r
* **Ignore list** — ignored event groups, with **Log again** and **Log all again**.\r
* **Logs and limits** — turn event types on and off, memory budget, event size limit and the **Used X of Y** indicator.\r
* **Data masking** — masking of sensitive data, patterns and the key list.\r
\r
#### Data storage and limits\r
\r
* Sensitive data is masked when an event is recorded, by keys and by value patterns, including JWT, **Bearer** / **Basic** and card numbers.\r
* The default memory budget is **20 MB**. When the limit is reached, older events are dropped.\r
* Pinia change history is compacted into a **Store checkpoint**, so the remaining changes can still be viewed.\r
* Repeated values are stored once and restored in full in the UI and in the HTML report.\r
* Events are stored whole by default. An optional event size limit of **512 KB** limits the volume by dropping large parts of events and truncating network bodies.\r
\r
### UI / UX\r
\r
* **Options** has a **Support Vue Inspector** section with links to Boosty and a USDT donation over Tron (TRC-20).\r
* Filter dropdowns use the UI kit scrollbar instead of the browser scrollbar.\r
* The favorites column in **Pinia** is aligned with the columns in **Props**, **Network** and **Logs**.\r
\r
### Fixes\r
\r
* Fixed the inspector failing to start when page global names clashed with names in the injected scripts.\r
* Fixed **Breakpoint** with relative request and response URLs.\r
* Fixed the display of the request and response data that was actually sent after a **Breakpoint** edit.\r
* Fixed applying edited \`XMLHttpRequest\` headers when the URL and method did not change.\r
* Fixed resolving relative URLs that were edited at a **Breakpoint**.\r
* Fixed saving removed keys when editing **Pinia** and **Props**.\r
\r
## [2.7.0] - 2026-11-18\r
\r
### AI assistant\r
\r
A new **AI** tab, after **Logs**. Describe the problem: the assistant explains what went wrong, the likely cause, the evidence and how to fix it. The same chat works in the extension and in **Bookmark** mode.\r
\r
**What you can ask**\r
\r
* Why a request failed, where an error comes from, or what changed after a navigation. The assistant starts from the captured logs and reads the page code when the logs are not enough. With source maps, the answer points at the original Vue file.\r
* Why a button is disabled, an element is hidden or a message appears — also when the logs recorded nothing. It checks the live page: the component, the current props and store state, and the conditions in the code.\r
* Where a value sits in the logged data: find it, list the matching rows or count them (for example filters that are visible by default, or rows with no price).\r
* How to reproduce the session: the clicks, in order, as a scenario.\r
* How Vue Inspector itself works: where a setting is and what a feature does.\r
\r
**Ask AI** on a row in **Network**, **Props**, **Pinia** or **Logs** attaches that item to the question. Several items can be attached. An event id in the answer opens that event on **Logs**.\r
\r
**Files**\r
\r
**+** next to the field attaches a **Text file** (TXT, LOG, JSON, HAR, MD, CSV, PDF) or a **Vue inspector Log**. Files can also be dropped on the field or pasted into it, up to 64 MB each. A long paste, over 4000 characters or 60 lines, becomes a **Pasted text** chip and is handled like a file.\r
\r
A text file goes with the question it was attached to. The assistant can read it again in later questions of the same chat, and **New chat** drops it. An exported log stays pinned to the chat: the logs digest and the logs tools read it instead of the live capture until **New chat**.\r
\r
A small file goes to the assistant whole. A bigger file is not sent: the assistant gets an overview and tools to search the file, read parts of it and query JSON or HAR by path. The first step of the answer says **(overview; content read with file tools)**. For a PDF only the text layer is read; scanned pages and password-protected files are refused.\r
\r
The answer appears as it is written. Stopping keeps the text written so far; reasoning stays on one line until you expand it. Under the answer: which model answered, how many requests it took, tokens and time. A follow-up sends only the events captured since the last answer.\r
\r
**Connection and models**\r
\r
**Options → AI → Connection** takes a free API key of **Gemini** (Google AI Studio) or **OpenRouter**. **Your own providers** adds OpenAI, DeepSeek, Ollama, LM Studio or any OpenAI-compatible server or agent, with an optional API key. The key stays in this browser: it is not part of settings export, and **Reset** does not remove it.\r
\r
The model list starts with **Auto**. Auto picks an available model and moves to the next when one runs out of quota, cannot be used with the key, or is overloaded, and it remembers that until the quota resets, the key changes, or the model is free again. A model you pick yourself is always the one used. When it fails, the answer says why and offers **Switch to Auto and try again**. The line under the message field shows today's requests and how many models Auto is skipping.\r
\r
**Options → AI → Models** lists the recommended models and the ones you add, free and paid. Uncheck a model to hide it from the tab and from **Auto**. Each row shows today's requests and, when it applies, that the quota is used up, the key cannot use it, or it is busy. Models whose providers are down are hidden; models that fail often are marked **unstable**.\r
\r
**How answers are written**\r
\r
**Options → AI → Personalization**:\r
\r
* **Base style and tone** — **Default**, **Professional**, **Friendly**, **Direct** or **Mentor**.\r
* **Answer detail** — **Brief** (cause, evidence and the fix), **Normal**, or **Detailed** (the chain of events, ruled-out causes, steps to reproduce).\r
* **Instruction routing** — **Full** sends every task instruction with each request, for strong models. **Lite** sends the core rules and loads the instructions of the current task.\r
* **Your style instructions** — your own text, up to 2000 characters. For example: answer in Russian, end with a checklist for the bug report.\r
\r
**What may be sent**\r
\r
Before the first question the tab shows what goes to the provider. **I understand** confirms it. **Review access** opens **Agent access**.\r
\r
**Options → AI → Agent access** sets what the assistant may read and send:\r
\r
* **Attach the logs digest** — a short summary of errors and the timeline. On by default; off, the question goes out without it.\r
* **Logs**, **Page code** and **Live page** — each is **Allowed**, **Ask each time** or **Off**. **Off** means that group is not offered. **Ask each time** (the default) shows the call and waits for **Allow**, **Allow in this chat** or **Deny**.\r
* **Request and response headers**, **bodies and WebSocket messages**, and **values of store state, props, emits and actions** — each **Allowed** or **Off**. Off, names and types stay, values do not. Headers are the ones the page itself can see.\r
\r
The first step of an answer says what was sent, which access is in force and how many values were masked.\r
\r
**Options → AI → Data masking for AI** is a separate list from **Logs**. Passwords, tokens, API keys, cookies, sessions and token-like values (JWT, Bearer, card numbers) are sent as \`[MASKED]\`, including values found in page code. The **Logs** view and its exports stay as they are.\r
\r
---\r
\r
### Props\r
\r
**Save as**, under the buttons of a component card, chooses what **Save** keeps. **Once** changes the live component only and removes a rule it already has. **Part** stores just the props changed in this edit. **Full** stores every current prop. A component has one of these. After a reload, or when the component is created again, a Part or Full rule is applied before \`setup()\` and the first render. The rule matches this component name at the same route of parent components, on the site where it was saved. Values are JSON, so functions cannot be kept.\r
\r
While a rule applies, updates from the parent do not overwrite it. Turning the rule off or deleting it gives the component the parent's current value back at once, without a reload.\r
\r
A row with a rule has a purple bar on the left, and the selected row has a purple background, like a mocked request on **Network**. The Props toolbar shows a pin with how many rules apply on this page out of the total; the card shows a pin with the number of props the rule holds. Both open **Options → Props → Prop rules**. **Save as** shows **Part** or **Full** when a rule applies, and **Once** otherwise. It can be changed only while editing; **Cancel** restores it. **Delete rule** in the row menu deletes the rule at once.\r
\r
**Options → Props → Prop rules**, after **Favorite Components**, lists the rules. **Apply rules** turns them all off without deleting them. The row menu has **Edit**, **Enable** / **Disable** and **Delete**.\r
\r
In the extension the rules apply on page load even when the panel is closed. A page that loads Vue 3.3 or newer through a bundler gets the values on the first render. Other builds and Vue 2 get them once the inspector starts.\r
\r
---\r
\r
### Logs\r
\r
**Export for AI**, next to **Export Logs**, downloads a short Markdown digest of the selected events, or of every event that matches the filters. It is meant to be handed to an assistant and is many times smaller than the full report: how to read the file, a **Summary**, grouped **Problems** and a **Timeline**. An event id \`#N\` opens the same event in the HTML report.\r
\r
**Click** records a primary click: the control and the text on it. A click on an icon inside a button is recorded as the button. Clicks on Vue Inspector itself are skipped, and the value of a password or hidden field is not stored. **Clicks** is its own switch in **Options → Logs**, on by default.\r
\r
A request and its response are exported together. The **ignored** badge opens **Options → Logs** at the ignore list.\r
\r
### Network\r
\r
* A WebSocket row can be sent to the assistant with **Ask AI**.\r
* The **bp** and **mock** badges open **Options → Network** at the breakpoints or mocks. A pulsing pending breakpoint still selects the first pending row.\r
* WebSocket **Messages** read as a chat: the composer at the bottom, sent frames on the right, received on the left, newest at the bottom.\r
\r
### HTML report\r
\r
* **Export for AI** downloads the same digest. **Export JSON** saves the full report data, including from a compressed report. On a narrow screen the buttons are **Export AI** and **JSON**.\r
* **Failed requests / WS** also counts WebSocket connections that closed with an error, closed without reconnecting, or failed.\r
* **Page** lists **Click** next to **Navigation** and **JS error**.\r
\r
### Options → Logs\r
\r
* **Compress report**, on by default, stores the report as gzip. The file is several times smaller and opens the same way. It needs Chrome / Edge 80+, Firefox 113+ or Safari 16.4+. In a browser without gzip the option is off and the report stays uncompressed.\r
* **Requests** and **WebSocket** are separate switches. WebSocket can be turned off while HTTP requests stay on.\r
* The **Ignore list** is shown again, above **Data masking**.\r
\r
### Language\r
\r
**Options → General → Language** switches the inspector interface. The choice is saved with the settings and starts as English. Available languages: English, Spanish, Simplified Chinese, German, French, Japanese, Portuguese (Brazil), Russian, Korean, Italian, Polish, Turkish, and Arabic.\r
\r
### Fixes\r
\r
* Fixed the false **Body truncated** notice on complete responses with non-ASCII text, such as Cyrillic. Reports exported before this fix no longer show that notice either.\r
* Removed **Search by Label** in **Props**. The checkbox did not filter the list.\r
* The **Support Vue Inspector** title lines up with the text of the card.\r
* Minor layout fixes.\r
`,_=`---\r
title: Standalone\r
---\r
\r
# Standalone application\r
\r
> If the browser does not support the extension, or policy blocks extension installation or access to \`chrome://extensions\`, Vue Inspector can be launched via a **bookmarklet** on the current page — without installing the extension.\r
\r
## Data storage\r
\r
Standalone uses **its own local storage**: settings and media persist between launches and are **not tied to a single site**. Like the extension, it provides **a single shared profile across all domains** where the bookmark is used. Full comparison with the extension is available in [Installation → Where settings are stored](./install#storage); media limits for background assets are described in [Customize](/options/customize).\r
\r
---\r
\r
## Installation\r
\r
1. Open the <a href="../../index.html#installation" target="_self" rel="noopener">installation section</a> on the main project page.\r
2. Under **Bookmarklet Mode**, drag the **Vue Inspector** button to the browser bookmarks bar.\r
\r
---\r
\r
## Usage\r
\r
1. Open a page with a Vue application;\r
2. Click the saved **Vue Inspector** bookmark;\r
3. The inspector panel opens at the bottom of the page.\r
`,D=`---\r
title: Favorites\r
---\r
\r
# Favorites (Pinia stores)\r
\r
**Favorite stores** are a persisted list of **Pinia stores** for faster navigation on **Stores**: starred rows move **to the top**, show a **star**, and a header badge counts how many favorites match the current results.\r
\r
Store overview: [Overview](/store/general).\r
\r
**Vue component** favorites (**Props** tab) are separate: [Favorites (Props)](/props/favorite).\r
\r
---\r
\r
## Add and remove\r
\r
* **In the store card** — header **star** toggles favorite.\r
* **Row context menu** on **Stores** — add/remove favorite.\r
* **Stores table** — click the **star** area on a row.\r
* **Options → Pinia Store → Favorite Stores** — the list and its details card are below.\r
\r
Settings persist in the inspector profile with other options.\r
\r
---\r
\r
## Exact names and wildcards\r
\r
Each entry defines a **store name pattern**.\r
\r
* Without **\`*\`**, matching is **exact** and case-sensitive: the star appears only for that store name.\r
* **\`*\`** is any sequence, and the pattern must match the whole name. Example: **\`use*Store\`** matches **useUserStore** and **useAuthStore**. Case is significant.\r
\r
Removing favorite from a row clears **all** rules that match that store (exact and wildcard).\r
\r
Manual entry in **Options** uses the same wildcard rules.\r
\r
---\r
\r
## What is stored\r
\r
Per entry the inspector keeps:\r
\r
* **id** and **name**, both set to the displayed store name when you star a row (a mask typed in Options is stored in these strings);\r
* **storeId** of the instance at the moment it was starred. The star does not use this field;\r
* **time added**.\r
\r
That lets favorites apply again after the store list rebuilds.\r
\r
---\r
\r
## Matching\r
\r
The displayed name (\`baseId\`) is compared with each entry’s **id** and **name**. An exact equality or a \`*\` pattern on either field stars the row. Comparison is case-sensitive. The stored **storeId** is not part of the match.\r
\r
If several stores match one mask, every matching row shows a star.\r
\r
---\r
\r
## Sorting and badge\r
\r
The table keeps favorite rows on top.\r
\r
The badge is always shown. It reads \`0\` when nothing is saved, otherwise visible favorites / saved total. It is yellow when at least one visible row is a favorite.\r
\r
Clicking the badge opens **Options → Pinia Store → Favorite Stores**.\r
\r
---\r
\r
## Favorite Stores in Options\r
\r
The block is second on **Options → Pinia Store**. The add field placeholder is **Store name (supports wildcards: *Store*)**. **Add** or **Enter** trims the text and appends a row whose **id** and **name** are that string. There is no **storeId**. An empty value shows **Name cannot be empty**. The same **id** or **name** already in the list shows **This store is already in favorites**. That check is the exact string, so \`Foo\` and \`foo\` are two rows, and a mask is not treated as a duplicate of a name it would match.\r
\r
Rows stay in the saved order.\r
\r
| Column | What it shows |\r
| ------ | ------------- |\r
| **Store Name** | The stored name. |\r
| **Added** | The locale date only. |\r
\r
The row menu (right click or **⋮**) is **Edit** and **Delete**. **Delete** removes every entry with that **id**. It does not clear other patterns that merely match the same store. The empty table says *No favorite stores*.\r
\r
A click opens **Favorite Store Details**: **Store Name** and **Added** as the locale date and time. **Edit** in the row menu opens that card already in edit mode. The header **Edit** icon does the same on an open card. The field placeholder is **Store name**. **Enter** or **Save** writes the trimmed text into both **id** and **name** and keeps **storeId** if the row had one. **Save** is disabled while the field is blank, and it does not check for another row with the same name. **Cancel** leaves edit mode and stays on the card. **Back** or **Escape** closes the card, including during edit.\r
\r
With nothing selected the panel says *Select an item to see details*. If the entry was removed while the card is open, it says *Item no longer exists*. Below **1000** px the card covers the settings list until you go back.\r
\r
The card does not select that store on the Stores tab.\r
\r
---\r
\r
## Tips\r
\r
* Favorite **core** stores: user, settings, UI shell.\r
* **Patterns** help uniform naming schemes; overly broad masks may over-select.\r
* Favorites **do not** change Pinia runtime; they are local inspector metadata.\r
\r
---\r
\r
## See also\r
\r
* [Store overview](/store/general)\r
* [Favorites (Props)](/props/favorite)\r
* [Customize](/options/customize)\r
`,L=`---\r
title: Pinia stores\r
---\r
\r
# Pinia stores\r
\r
The **Stores** tab is for inspecting **Pinia** stores registered in the app: name (id), **state** and **getter** field counts, and—after you select a row—a snapshot of **state** and **getters** that you can edit and write back where supported.\r
\r
More on editing **state** and **getters**, and **favorites** for stores:\r
\r
* [State](/store/state)\r
* [Getters](/store/getters)\r
* [Favorites](/store/favorite)\r
\r
## Top toolbar\r
\r
![Store, область заголовка](/screenshots/Store_header.jpg)\r
\r
### Store search\r
\r
The field placeholder is **Search stores...**. Active criteria come from **Search by**. The same checkboxes are the first block on **Options → Pinia Store**, under **Search Settings**: **Search by store name**, **Search by key**, **Search by value**. Defaults: name on; key and value off. A change applies to the open list immediately.\r
\r
On **Options → Pinia Store** the blocks follow in this order: **Search Settings**, then **Favorite Stores**.\r
\r
| Mode      | What the list uses                                                                 |\r
| --------- | ---------------------------------------------------------------------------------- |\r
| **Name**  | the displayed store name (\`baseId\`), in the panel                                  |\r
| **Key**   | field names in **state** and **getters**, asked from the page                      |\r
| **Value** | field values in **state** and **getters**, asked from the page                     |\r
\r
A non-empty query keeps a store when any enabled mode matches. With all three off, the query matches nothing.\r
\r
Minimum length applies to every mode. Default **2** characters and **300 ms** debounce, from **Options → General → Search Parameters** ([Update settings](/options/update_settings)). A shorter non-empty query does not start a new search; the previous result stays until the field is cleared or the query reaches the minimum.\r
\r
**Key** and **Value** also skip the page search below that length. The page walks state and getters to depth 20 and returns at most **100** stores. If that request fails, **Key** and **Value** match nothing; **Name** still filters in the panel.\r
\r
**Partial vs exact.** If the query is **not** wrapped in quotes, matching is a **substring** (case-insensitive). **Exact** whole-string match applies when the **entire** query is wrapped in **double quotes** \`"..."\`.\r
\r
### Status chips\r
\r
Right side of **Stores**:\r
\r
| Item              | Purpose                                                                                                                                 |\r
| ----------------- | --------------------------------------------------------------------------------------------------------------------------------------- |\r
| **N** or **N/M**  | **N** is visible stores. **/M** appears only when the search field is not empty and the counts differ. **M** is the last summary. |\r
| **Favorites** ★   | Visible favorites / saved total, or \`0\` when none are saved. Yellow when at least one visible row is a favorite. Click opens **Options → Pinia Store → Favorite Stores**. |\r
| **Update**        | **Refresh** (disabled while a summary load runs) and the local time of the last successful summary, or \`Loading...\`. |\r
\r
Before a summary, the panel pings the page. If that ping fails, nothing is requested: the list stays empty (**No stores found**) and there is no error overlay. A summary that never arrives shows **Timeout: Pinia stores not found or not initialized** after 3 seconds. A failed request shows **Failed to load Pinia stores. Make sure Pinia is installed and initialized.** The message covers the tab.\r
\r
## Work area\r
\r
![Pinia, полноэкранный режим](/screenshots/Pinia_full_screen.jpg)\r
\r
### Store list\r
\r
Left: the store table. **Name** is always shown. The column menu toggles **State** and **Getters**; both default to on. An empty list says **No stores found**.\r
\r
* **Name** — displayed store name (\`baseId\`), or **Unknown Store** when it is missing;\r
* **State** — number of state keys, or **—** when the count is 0;\r
* **Getters** — number of getters, or **—** when the count is 0.\r
\r
Any row opens the card. Favorite rows stay on top. The row menu is **Ask AI** and **Add favorite** / **Remove favorite**. The star on the row does the same favorite toggle. See [Favorites](/store/favorite).\r
\r
**Ask AI** is always available. It loads the store from the page and attaches state and getters. If that read fails, a toast says **Could not read the store {name}**. Otherwise the **AI** tab opens with a chip above the input, for example *Store cart*: **×** removes it from the question. Type a question, or send the chip without one. When **Logs** has a change of this store, the attachment also names the latest one as \`#N\`. Values are masked by the AI settings and cut; with **Values of store state, props, emits and actions** off, the assistant gets only names and types.\r
\r
## Store details\r
\r
Selecting a row opens the detail panel. With nothing selected it says **Select a store to see details**. Below **1000** px the card covers the list.\r
\r
### Summary header\r
\r
The top of the panel shows:\r
\r
* store name;\r
* **State: N** when the state count is above zero;\r
* **Getters: N** when the getter count is above zero;\r
* an **Updated:** line. While the first load runs it says \`Loading...\`. After a successful read it is UTC \`YYYY-MM-DD HH:mm:ss\` (the toolbar clock is local).\r
\r
### Store data\r
\r
Below that, tabs:\r
\r
| Tab         | Purpose                                                                                                                      |\r
| ----------- | ---------------------------------------------------------------------------------------------------------------------------- |\r
| **State**   | snapshot of reactive **state**; view and save changes                                                                         |\r
| **Getters** | snapshot of current **getter** values in serialized form; view and limited editing depending on the scenario                |\r
\r
A tab is shown only when its count is above zero. The card opens on **State** when that count is above zero, otherwise on **Getters**. While the snapshot loads, the body says **Loading store data...**. A missing section says **No state data** or **No getters data**.\r
\r
The active tab is shown as **JSON**—text or tree—according to inspector settings.\r
\r
### Navigation\r
\r
* **← Back** closes the card, including during edit;\r
* **Esc** in edit mode discards the draft and stays on the card;\r
* **Esc** outside edit mode closes the card.\r
\r
### Controls\r
\r
| Control     | Purpose                                                                                              |\r
| ----------- | ---------------------------------------------------------------------------------------------------- |\r
| **Star**    | add or remove the store from favorites. Tooltip: **Add to favorites** / **Remove from favorites** |\r
| **Refresh** | re-fetch this store. Tooltip **Refresh data**. Disabled while the card is loading. Hidden in edit mode |\r
| **Edit**    | enter edit mode for the active tab. Tooltip **Edit state** or **Edit getters** |\r
\r
### Edit mode\r
\r
Button order in view mode: **Star → Refresh → Edit**. After **Edit**, **Refresh** and **Edit** become **Cancel** and **Save**. **Star** stays.\r
\r
| Before editing | In edit mode                                                    |\r
| -------------- | --------------------------------------------------------------- |\r
| **Refresh**    | **Cancel** — discard changes and leave edit mode                |\r
| **Edit**       | **Save** — apply changes to the app                            |\r
\r
**Save** is disabled when the JSON does not parse. Changes apply only after **Save**. There is no toast. If the page rejects the write, edit mode stays open and the failure is in the console. On success, edit mode ends and a result message reloads the snapshot.\r
\r
For **State**, the store’s current state is updated; for **Getters**, writing is only supported in valid scenarios, and limits depend on how the store is implemented.\r
\r
The **favorite** star in this panel and in the table is described on [Favorites](/store/favorite).\r
\r
Card data reflects a **snapshot from the last request**: changes in the app are not reflected automatically until you **Refresh** in the card or refresh the summary from the **Stores** top toolbar.\r
\r
## Display limits\r
\r
### Reading limits\r
\r
1. **All-stores summary** — lightweight: each store gets id, name, **state** / **getter** key counts, and a snapshot timestamp, **without** full value serialization.\r
2. **Selected store card** — a separate request with serialized **state** and **getters** for display and editing.\r
\r
**State** and **getter** serialization uses depth and size limits: cycles, functions, and special objects may be truncated or shown differently than in raw runtime.\r
\r
**Key** / **Value** search returns at most **100** stores and walks values to depth 20.\r
\r
### Capacity\r
\r
There is no fixed cap on how many stores appear in the table: typical **Pinia** summary responses list them all.\r
\r
Unusual registration or extreme setups may be incomplete. Whether a write succeeds depends on the store. A failed save stays in edit mode and is logged in the console.\r
\r
## How it works\r
\r
### When collection starts\r
\r
The injected Pinia module hooks in after **Pinia** is detected on the page (same idea as **Props**: Vue and the inspector must be active).\r
\r
If Pinia is not installed or not initialized when you open **Stores**, the list stays empty or you may see a load error.\r
\r
### What is monitored\r
\r
1. **Summary** — ids, names, and field counts for the table only.\r
2. **Single store details** — full serialized **state** and **getters** when you drill in.\r
\r
That keeps a **fast list** separate from **heavy reads** for one store.\r
\r
### Messaging\r
\r
The panel does not read Pinia directly: it sends a message to the page context where registered stores are available.\r
\r
\`\`\`js\r
// Illustration: summary request — store id, name, and key counts only\r
const response = await bridge.send({ type: 'PINIA_GET_STORES_SUMMARY' })\r
// response.summary — map storeId → { id, baseId, stateKeys, getterKeys, … }\r
\r
const detail = await bridge.send({\r
  type: 'PINIA_GET_STORE_STATE',\r
  storeId: 'my-store-id',\r
})\r
// detail.state, detail.getters — data for display and editing\r
\`\`\`\r
\r
Key/value search (\`PINIA_SEARCH\`) runs in the page and returns only matching store ids.\r
\r
## See also\r
\r
* [State](/store/state)\r
* [Getters](/store/getters)\r
* [Favorites](/store/favorite)\r
* [Update settings](/options/update_settings)\r
`,B=`---\r
title: Getters\r
---\r
\r
# Getters (Pinia)\r
\r
In **Stores**, **Getters** shows **current values** of computed fields and other properties Pinia exposes on the store instance beside **state**. Values are read from the live page, serialized for the JSON editor, and on save are applied via **patch** logic back into the app.\r
\r
Context: [Store overview](/store/general). **State** editing: [State](/store/state).\r
\r
---\r
\r
## Which fields count as getters\r
\r
\`getGetterKeys\` in \`src/injected/pinia/store-meta.ts\` collects **computed** on setup stores, keys present on \`store\` but missing from \`$state\`, and prototype properties with **get** (options stores).\r
\r
\`\`\`ts\r
function getGetterKeys(store) {\r
  const getters = []\r
  const stateKeys = new Set(Object.keys(store.$state || {}))\r
  // 1) store fields detected as computed refs\r
  // 2) key on store but not in $state\r
  // 3) getter without setter on prototype\r
  return getters\r
}\r
\`\`\`\r
\r
The summary column (**Getters: N**) shows that count.\r
\r
---\r
\r
## Reading for the UI\r
\r
\`getStoreGetters\` in \`src/injected/pinia/getters.ts\` stores \`unwrapValue(store[key])\` per getter key; errors become \`[Non-serializable]\`.\r
\r
\`\`\`ts\r
function getStoreGetters(storeId) {\r
  const store = getStore(storeId)\r
  if (!store) return {}\r
  const result = {}\r
  for (const key of getGetterKeys(store)) {\r
    try {\r
      result[key] = unwrapValue(store[key])\r
    } catch {\r
      result[key] = '[Non-serializable]'\r
    }\r
  }\r
  return result\r
}\r
\`\`\`\r
\r
Opening the card requests \`PINIA_GET_STORE_STATE\`; **getters** render in the **Getters** tab (text or tree JSON).\r
\r
---\r
\r
## Edit and save\r
\r
Saving **Getters** sends \`PINIA_PATCH_GETTERS\` with parsed JSON from the editor (\`PiniaDetails.vue\`).\r
\r
\`\`\`ts\r
async function saveGettersChanges() {\r
  const newGetters = JSON.parse(editedGettersJson.value)\r
  const response = await runtime.sendMessage({\r
    type: 'PINIA_PATCH_GETTERS',\r
    storeId,\r
    newGetters\r
  })\r
  if (response?.success) {\r
    gettersData.value = newGetters\r
    isEditingGetters.value = false\r
  }\r
}\r
\`\`\`\r
\r
\`patchGetters\` in \`src/injected/pinia/state-writer.ts\` **does not assign to pure readonly computed**; inside \`store.$patch\` it tries **backing** fields — writes to \`$state\`, writable refs, reactive merge; otherwise skips.\r
\r
\`\`\`ts\r
function patchGetters(storeId, newGetters) {\r
  const store = getStore(storeId)\r
  const updated = []\r
  store.$patch(() => {\r
    for (const [key, newValue] of Object.entries(newGetters)) {\r
      if (key in store.$state) {\r
        store.$state[key] = newValue\r
        updated.push(key)\r
      } else if (isWritableRef(store[key])) {\r
        store[key].value = newValue\r
        updated.push(key)\r
      } else if (canMergeReactive(store[key], newValue)) {\r
        mergeReactive(store[key], newValue)\r
        updated.push(key)\r
      }\r
      // pure computed — skip\r
    }\r
  })\r
  return { success: true, updated }\r
}\r
\`\`\`\r
\r
Response: \`PINIA_PATCH_GETTERS_RESULT\` (\`success\`, \`updated\`). **Refresh** afterward to confirm displayed getters match the app.\r
\r
**Removing keys.** As for [State](./state.md#removing-keys), keys deleted in the editor are sent as \`removedPaths\`. A getter itself cannot be removed, so only keys **inside** a getter value are deleted — this works when the getter returns an object from state.\r
\r
---\r
\r
## Notes\r
\r
* If a name matches **state**, the patch hits **\`$state[key]\`** — you change the source of truth.\r
* Pure read-only computed with no writable backing **won’t** change; use **state** or **actions**.\r
* Non-serializable reads show placeholders; edit carefully or via **state** / **actions**.\r
\r
---\r
\r
## See also\r
\r
* [State](/store/state)\r
* [Store overview](/store/general)\r
* [Favorites](/store/favorite)\r
`,M=`---\r
title: State\r
---\r
\r
# State (Pinia)\r
\r
In **Stores**, for the selected store, **State** shows a snapshot of **reactive fields** that belong to store state: for options stores mainly **\`$state\`** keys; for setup stores — refs and reactive objects on the store instance (excluding **computed** getters). Values go through \`unwrapValue\`, render in the JSON editor, and **Save** applies back via **\`store.$patch\`** inside \`replaceState\`.\r
\r
Context: [Store overview](/store/general). Computed-style patching: [Getters](/store/getters).\r
\r
---\r
\r
## Which keys appear in the state snapshot\r
\r
Key names come from \`getStoreStateKeys\` (\`src/injected/pinia/store-meta.ts\`): when \`$state\` exists, its keys are used; otherwise the store instance is scanned (skipping \`$\` / \`_\` / functions / **computed**).\r
\r
\`\`\`ts\r
function getStoreStateKeys(store) {\r
  if (store.$state && typeof store.$state === 'object') {\r
    return Object.keys(store.$state)\r
  }\r
  // setup-store: non-functions only, not isComputedRef(...)\r
  return collectEligibleKeysFromStoreInstance(store)\r
}\r
\`\`\`\r
\r
---\r
\r
## Reading for the UI\r
\r
\`createSnapshot\` / \`getStoreState\` in \`src/injected/pinia/state-reader.ts\` call \`unwrapValue\` per key; failures become \`[Non-serializable]\`.\r
\r
\`\`\`ts\r
function createSnapshot(store) {\r
  const snapshot = {}\r
  for (const key of getStoreStateKeys(store)) {\r
    try {\r
      snapshot[key] = unwrapValue(store[key])\r
    } catch {\r
      snapshot[key] = '[Non-serializable]'\r
    }\r
  }\r
  return snapshot\r
}\r
\r
function getStoreState(storeId) {\r
  const store = getStore(storeId)\r
  return store ? createSnapshot(store) : null\r
}\r
\`\`\`\r
\r
The bridge in \`src/injected/pinia/bridge.ts\` answers \`PINIA_GET_STORE_STATE\` with \`PINIA_STORE_STATE_DATA\` containing **state**, **getters**, and **actions** — the **State** tab uses \`state\`.\r
\r
\`\`\`ts\r
function handleGetStoreState({ storeId, requestId }) {\r
  const state = tryGet(() => getStoreState(storeId))\r
  const getters = tryGet(() => getStoreGetters(storeId))\r
  const actions = tryGet(() => getStoreActions(storeId))\r
  postMessage({ type: 'PINIA_STORE_STATE_DATA', storeId, state, getters, actions, requestId })\r
}\r
\`\`\`\r
\r
\`PiniaDetails.vue\` loads this when the card opens and fills the editor.\r
\r
\`\`\`ts\r
async function loadStoreData() {\r
  const response = await runtime.sendMessage({\r
    type: 'PINIA_GET_STORE_STATE',\r
    storeId\r
  })\r
  if (response && 'state' in response) stateData.value = response.state ?? {}\r
  if (response && 'getters' in response) gettersData.value = response.getters ?? {}\r
  await nextTick()\r
  editedStateJson.value = JSON.stringify(stateData.value, null, 2)\r
  // …same for getters JSON\r
}\r
\`\`\`\r
\r
---\r
\r
## Save: full state replace from the editor\r
\r
The UI edits the whole state JSON; saving sends \`PINIA_REPLACE_STATE\` with \`newState\` (\`PiniaDetails.vue\` → injected \`replaceState\` in \`src/injected/pinia/state-writer.ts\`).\r
\r
\`\`\`ts\r
async function saveStateChanges() {\r
  const newState = JSON.parse(editedStateJson.value)\r
  const response = await runtime.sendMessage({\r
    type: 'PINIA_REPLACE_STATE',\r
    storeId,\r
    newState\r
  })\r
  if (response?.success) {\r
    stateData.value = newState\r
    isEditingState.value = false\r
  }\r
}\r
\`\`\`\r
\r
\`\`\`ts\r
function replaceState(storeId, newState) {\r
  const store = getStore(storeId)\r
  if (!store) return false\r
  store.$patch(() => {\r
    for (const key of Object.keys(newState)) {\r
      if (shouldSkipKey(store, key)) continue // computed, read-only getter, function\r
      if (isRef(store[key])) store[key].value = newState[key]\r
      else if (isReactiveObject(store[key])) mergeIntoReactive(store[key], newState[key])\r
      else assignPrimitiveOrState(store, key, newState[key])\r
    }\r
  })\r
  return true\r
}\r
\`\`\`\r
\r
Success replies with \`PINIA_REPLACE_STATE_RESULT\`; the card may re-fetch \`PINIA_GET_STORE_STATE\` to resync.\r
\r
### Removing keys\r
\r
The merge above never deletes keys on its own, so keys removed in the editor are sent explicitly: before saving, the UI compares the loaded snapshot with the edited JSON and adds \`removedPaths\` — the paths of deleted keys (arrays are replaced as a whole and are not compared inside).\r
\r
\`\`\`ts\r
const response = await runtime.sendMessage({\r
  type: 'PINIA_REPLACE_STATE',\r
  storeId,\r
  newState,\r
  removedPaths: findRemovedPaths(stateData.value, newState) // e.g. [['user', 'middleName'], ['discount']]\r
})\r
\`\`\`\r
\r
Inside the same \`store.$patch\`, after the merge:\r
\r
* **nested keys** are deleted from their object — getters and watchers react as to a missing field;\r
* **top-level keys** of an options store are deleted from \`$state\`;\r
* **top-level keys** of a setup store are set to \`undefined\`: deleting the ref would detach it from the store, so later writes would no longer reach the state.\r
\r
Only the keys you removed are deleted; everything else keeps the merge behavior.\r
\r
---\r
\r
## Path patch (\`PINIA_PATCH_STATE\`)\r
\r
\`state-writer.ts\` exposes **\`patchState(storeId, path, value)\`**: paths like \`a.b[0].c\` unwrap refs along the way; **computed** targets reject writes. \`PINIA_PATCH_STATE\` / \`PINIA_PATCH_STATE_RESULT\` exist, but **the State form only issues full replace** (\`PINIA_REPLACE_STATE\`).\r
\r
\`\`\`ts\r
function patchState(storeId, path, value) {\r
  const store = getStore(storeId)\r
  const { parent, lastKey, finalTarget } = navigatePath(store, path) // unwrap refs\r
  if (isComputedRef(finalTarget)) return false\r
  if (isRef(finalTarget)) finalTarget.value = value\r
  else parent[lastKey] = value\r
  return true\r
}\r
\`\`\`\r
\r
---\r
\r
## Notes\r
\r
* The snapshot is **not live** until you refresh.\r
* Keys outside \`getStoreStateKeys\` won’t show in UI; **extra** keys in pasted JSON may still attempt writes — outcome depends on the store.\r
* Treat \`[Non-serializable]\` carefully or use **actions**.\r
* Computed / read-only getters are skipped in \`replaceState\`; change underlying **state** or see [Getters](/store/getters).\r
\r
---\r
\r
## See also\r
\r
* [Getters](/store/getters)\r
* [Store overview](/store/general)\r
* [Favorites](/store/favorite)\r
`,F=Object.assign({"../../../documentation/ai/general.md":h,"../../../documentation/ai/settings.md":c,"../../../documentation/extension.md":p,"../../../documentation/general_principles.md":u,"../../../documentation/index.md":m,"../../../documentation/install.md":g,"../../../documentation/logs/export.md":f,"../../../documentation/logs/general.md":w,"../../../documentation/logs/settings.md":v,"../../../documentation/network/advanced.md":y,"../../../documentation/network/export.md":b,"../../../documentation/network/general.md":k,"../../../documentation/network/traffic.md":S,"../../../documentation/options/about.md":T,"../../../documentation/options/auto_run.md":x,"../../../documentation/options/customize.md":A,"../../../documentation/options/display_mode.md":I,"../../../documentation/options/json_mode.md":O,"../../../documentation/options/settings_management.md":P,"../../../documentation/options/update_settings.md":C,"../../../documentation/props/blacklist.md":R,"../../../documentation/props/favorite.md":N,"../../../documentation/props/general.md":q,"../../../documentation/props/inspect.md":E,"../../../documentation/releases/history.md":W,"../../../documentation/standalone.md":_,"../../../documentation/store/favorite.md":D,"../../../documentation/store/general.md":L,"../../../documentation/store/getters.md":B,"../../../documentation/store/state.md":M});function U(e){const r=e.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n/),s=r?.[1].match(/^title:\s*(.+)$/m)?.[1].trim()??"",t=e.slice(r?.[0].length??0).replace(/<!--[\s\S]*?-->/g,"").replace(/^[ \t]*!\[[^\]]*\]\([^)]*\)[ \t]*$/gm,"").replace(/^[ \t]*<\/?[a-z][^\n]*>[ \t]*$/gim,"").replace(/\n{3,}/g,`

`).trim();return{title:s,text:t}}function H(e){return e.toLowerCase().replace(/[^\p{L}\p{N}\s-]/gu,"").trim().replace(/\s+/g,"-")}function z(e){const r=[];let s=!1;return e.forEach((t,n)=>{/^\s*```/.test(t)&&(s=!s);const o=!s&&t.match(/^(#{1,6})\s+(.+?)\s*$/);if(!o)return;const a=o[2].match(/\s*\{#([^}]+)\}$/),d=o[2].slice(0,a?.index).replace(/[*`]/g,"");r.push({line:n,level:o[1].length,text:d,id:a?.[1]??H(d)})}),r}const l=Object.entries(F).map(([e,r])=>{const s={id:e.replace(/^.*\/documentation\//,"").replace(/\.md$/,""),...U(r)};return{...s,headings:z(s.text.split(`
`))}}).sort((e,r)=>e.id.localeCompare(r.id));function j(e,r){const s=r.trim().toLowerCase().replace(/^#/,""),t=[...e].sort((n,o)=>(n.level===1?1:0)-(o.level===1?1:0));return t.find(n=>n.text.toLowerCase()===s||n.id===s)??t.find(n=>n.text.toLowerCase().includes(s))}function V(e){const r=e.trim().toLowerCase().replace(/^\/+/,"").replace(/#.*$/,"").replace(/\.md$/,""),s=l.find(n=>n.id===r);if(s)return s;const t=l.filter(n=>n.id.split("/").pop()===r||n.title.toLowerCase()===r);return t.length===1?t[0]:t.length?t:l.filter(n=>n.id.includes(r))}function J(e,r){const s=e.text.split(`
`),t=e.headings,n=t.filter(i=>i.level>=2&&i.level<=3).map(i=>i.text),o=`# docs: ${e.id} (${e.title})`;if(!r)return n.length>2?`${o}
Sections: ${n.join("; ")}

${e.text}`:`${o}

${e.text}`;const a=j(t,r);if(!a)return`${o}
No section "${r}". Sections: ${n.join("; ")}`;const d=t.find(i=>i.line>a.line&&i.level<=a.level);return`${o}

${s.slice(a.line,d?.line).join(`
`).trim()}`}function G(e,r){const s=(Array.isArray(e)?e:e?[e]:[]).map(String).filter(Boolean).slice(0,3);return s.length?s.map(t=>{const n=t.match(/#(.+)$/)?.[1],o=V(t);return Array.isArray(o)?o.length?`Page "${t}" is ambiguous: ${o.map(a=>a.id).join(", ")}`:`No page "${t}". Pages: ${l.map(a=>a.id).join(", ")}`:J(o,r||n)}).join(`

---

`):l.map(t=>`${t.id} — ${t.title}: ${t.headings.filter(n=>n.level===2).map(n=>n.text).join("; ")}`).join(`
`)}export{G as readDocs};
